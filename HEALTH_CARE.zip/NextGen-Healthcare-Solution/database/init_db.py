import sqlite3
import os
import hashlib
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'database.db')
DB_PATH = os.path.abspath(DB_PATH)

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS specializations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        mobile TEXT NOT NULL,
        date_of_birth TEXT NOT NULL,
        gender TEXT NOT NULL,
        address TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'patient',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        blood_group TEXT,
        allergies TEXT DEFAULT '',
        emergency_contact TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        specialization_id INTEGER,
        qualification TEXT,
        experience INTEGER DEFAULT 0,
        consultation_fee REAL DEFAULT 0,
        about TEXT,
        availability TEXT DEFAULT 'available',
        rating REAL DEFAULT 4.5,
        available_days TEXT DEFAULT 'Mon-Fri',
        available_time TEXT DEFAULT '10:00 AM - 1:00 PM, 4:00 PM - 7:00 PM',
        image TEXT DEFAULT '',
        hospital TEXT DEFAULT '',
        languages TEXT DEFAULT '',
        expertise TEXT DEFAULT '',
        gender TEXT DEFAULT '',
        bio TEXT DEFAULT '',
        consultation_mode TEXT DEFAULT 'In-person',
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (specialization_id) REFERENCES specializations(id)
    )''')

    # Add new columns if table already exists (for migration)
    existing_columns = [row[1] for row in c.execute('PRAGMA table_info(doctors)').fetchall()]
    for col in ['image', 'hospital', 'languages', 'expertise', 'gender', 'available_time', 'bio', 'consultation_mode']:
        if col not in existing_columns:
            c.execute(f'ALTER TABLE doctors ADD COLUMN {col} TEXT DEFAULT ""')

    c.execute('''CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL,
        appointment_time TEXT NOT NULL,
        reason TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS medical_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        visit_date TEXT NOT NULL,
        diagnosis TEXT,
        symptoms TEXT,
        treatment TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS prescriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        medicine_name TEXT NOT NULL,
        dosage TEXT,
        frequency TEXT,
        duration TEXT,
        instructions TEXT,
        date TEXT NOT NULL,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS lab_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_name TEXT NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        test_date TEXT NOT NULL,
        result TEXT,
        reference_range TEXT,
        status TEXT DEFAULT 'pending',
        remarks TEXT,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT,
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        description TEXT,
        ip_address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS telehealth (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_id INTEGER,
        doctor_id INTEGER,
        patient_id INTEGER,
        consultation_date TEXT,
        consultation_time TEXT,
        status TEXT DEFAULT 'pending',
        session_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id),
        FOREIGN KEY (doctor_id) REFERENCES users(id),
        FOREIGN KEY (patient_id) REFERENCES users(id)
    )''')

    conn.commit()

    specializations_data = [
        ('Cardiology', 'Heart and cardiovascular system specialists'),
        ('Dermatology', 'Skin, hair, and nail specialists'),
        ('Neurology', 'Brain and nervous system specialists'),
        ('Orthopedics', 'Bone, joint, and muscle specialists'),
        ('Pediatrics', 'Children\'s health specialists'),
        ('Oncology', 'Cancer diagnosis and treatment'),
        ('Psychiatry', 'Mental health and behavioral disorders'),
        ('Gastroenterology', 'Digestive system specialists'),
        ('Pulmonology', 'Lung and respiratory system specialists'),
        ('Endocrinology', 'Hormone and gland specialists'),
        ('Urology', 'Urinary tract and kidney specialists'),
        ('Ophthalmology', 'Eye care and vision specialists'),
        ('Dentistry', 'Oral health and dental care'),
        ('General Medicine', 'Primary care and general health'),
        ('Gynecology', 'Women\'s reproductive health'),
    ]
    for name, desc in specializations_data:
        c.execute('INSERT OR IGNORE INTO specializations (name, description) VALUES (?, ?)', (name, desc))

        # ===== 150 DOCTORS (10 PER SPECIALIZATION) =====
    # ===== WORLD-WIDE DOCTORS: every doctor belongs to a country; names, cities, languages follow it =====
    # (country, languages, cities, male first names, female first names, last names)
    COUNTRIES = [
        ("India", "Hindi, English", ["Chennai", "Mumbai", "Delhi"], ["Arjun","Karthik","Naveen","Rohit","Siddharth","Anand"], ["Priya","Kavitha","Meera","Divya","Lakshmi","Revathi"], ["Krishnan","Sharma","Nair","Reddy","Iyer","Menon"]),
        ("USA", "English, Spanish", ["New York", "Chicago", "Houston"], ["James","Michael","William","Daniel","Ethan","Andrew"], ["Emily","Jessica","Sarah","Olivia","Megan","Rachel"], ["Anderson","Thompson","Martinez","Clark","Walker","Hughes"]),
        ("United Kingdom", "English", ["London", "Manchester", "Edinburgh"], ["Oliver","Harry","George","Jack","Thomas","Edward"], ["Charlotte","Amelia","Isla","Grace","Poppy","Hannah"], ["Whitaker","Hargreaves","Fletcher","Ashworth","Pemberton","Sutton"]),
        ("Canada", "English, French", ["Toronto", "Vancouver", "Montreal"], ["Liam","Noah","Lucas","Owen","Nathan","Connor"], ["Chloe","Zoe","Avery","Madison","Lily","Ruby"], ["MacDonald","Tremblay","Campbell","Gagnon","Fraser","Bouchard"]),
        ("Australia", "English", ["Sydney", "Melbourne", "Brisbane"], ["Mitchell","Jarrod","Cameron","Brodie","Hamish","Lachlan"], ["Matilda","Tahlia","Sienna","Imogen","Harper","Indi"], ["Kelly","Sinclair","Murray","Gallagher","Donovan","Pearce"]),
        ("Germany", "German, English", ["Berlin", "Munich", "Hamburg"], ["Lukas","Felix","Maximilian","Jonas","Matthias","Stefan"], ["Anna","Lena","Katharina","Johanna","Greta","Lisa"], ["Schneider","Hoffmann","Becker","Wagner","Fischer","Keller"]),
        ("France", "French, English", ["Paris", "Lyon", "Marseille"], ["Louis","Hugo","Antoine","Julien","Mathieu","Etienne"], ["Camille","Manon","Juliette","Margaux","Elodie","Claire"], ["Dubois","Laurent","Moreau","Fontaine","Girard","Lefevre"]),
        ("Spain", "Spanish, English", ["Madrid", "Barcelona", "Valencia"], ["Javier","Alejandro","Pablo","Sergio","Diego","Alvaro"], ["Lucia","Carmen","Marta","Elena","Paula","Irene"], ["Garcia","Fernandez","Navarro","Ortega","Molina","Castillo"]),
        ("Italy", "Italian, English", ["Rome", "Milan", "Florence"], ["Marco","Giovanni","Luca","Matteo","Alessandro","Davide"], ["Giulia","Chiara","Francesca","Elisa","Valentina","Sofia"], ["Rossi","Bianchi","Ferrari","Romano","Conti","Greco"]),
        ("Sweden", "Swedish, English", ["Stockholm", "Gothenburg", "Malmo"], ["Erik","Oskar","Anders","Magnus","Johan","Henrik"], ["Astrid","Ingrid","Elsa","Freja","Linnea","Maja"], ["Lindqvist","Johansson","Eriksson","Nilsson","Bergstrom","Holm"]),
        ("Russia", "Russian, English", ["Moscow", "Saint Petersburg", "Kazan"], ["Dmitri","Alexei","Ivan","Nikolai","Sergei","Pavel"], ["Natalia","Olga","Svetlana","Irina","Tatiana","Ksenia"], ["Volkov","Smirnov","Kuznetsov","Orlov","Sokolov","Morozov"]),
        ("Turkey", "Turkish, English", ["Istanbul", "Ankara", "Izmir"], ["Mehmet","Emre","Burak","Kerem","Hakan","Onur"], ["Elif","Zeynep","Defne","Merve","Ayse","Selin"], ["Yilmaz","Demir","Celik","Aydin","Sahin","Kaya"]),
        ("United Arab Emirates", "Arabic, English", ["Dubai", "Abu Dhabi", "Sharjah"], ["Khalid","Omar","Tariq","Yusuf","Hamza","Faisal"], ["Layla","Noura","Mariam","Salma","Hessa","Amira"], ["Al Mansoori","Al Hashimi","Al Nuaimi","Al Falasi","Haddad","Al Suwaidi"]),
        ("Egypt", "Arabic, English", ["Cairo", "Alexandria", "Giza"], ["Ahmed","Mostafa","Karim","Hossam","Tamer","Walid"], ["Nour","Hana","Dalia","Rania","Yasmin","Farida"], ["Hassan","Mahmoud","Farouk","Nasser","Soliman","Ibrahim"]),
        ("Nigeria", "English, Yoruba", ["Lagos", "Abuja", "Ibadan"], ["Chinedu","Emeka","Tunde","Obinna","Segun","Ikenna"], ["Ngozi","Folake","Chiamaka","Adaeze","Yetunde","Amara"], ["Okafor","Adeyemi","Balogun","Nwosu","Okonkwo","Eze"]),
        ("Kenya", "English, Swahili", ["Nairobi", "Mombasa", "Kisumu"], ["Kamau","Otieno","Mwangi","Kipchoge","Baraka","Juma"], ["Wanjiru","Achieng","Njeri","Zawadi","Akinyi","Mwajuma"], ["Kariuki","Odhiambo","Mutua","Kimani","Wekesa","Njoroge"]),
        ("South Africa", "English, Zulu", ["Johannesburg", "Cape Town", "Durban"], ["Thabo","Sipho","Pieter","Johan","Bongani","Willem"], ["Nomsa","Lerato","Thandi","Annelie","Zanele","Karabo"], ["Nkosi","Van der Merwe","Dlamini","Botha","Naidoo","Mokoena"]),
        ("Brazil", "Portuguese, English", ["Sao Paulo", "Rio de Janeiro", "Brasilia"], ["Rafael","Thiago","Gustavo","Bruno","Felipe","Leandro"], ["Beatriz","Mariana","Camila","Larissa","Fernanda","Juliana"], ["Silva","Oliveira","Costa","Pereira","Almeida","Barbosa"]),
        ("Argentina", "Spanish, English", ["Buenos Aires", "Cordoba", "Rosario"], ["Matias","Facundo","Nicolas","Santiago","Ezequiel","Joaquin"], ["Valentina","Agustina","Florencia","Candela","Julieta","Micaela"], ["Gomez","Rodriguez","Sosa","Acosta","Benitez","Ibarra"]),
        ("Mexico", "Spanish, English", ["Mexico City", "Guadalajara", "Monterrey"], ["Carlos","Miguel","Fernando","Ricardo","Eduardo","Jorge"], ["Guadalupe","Ximena","Fernanda","Daniela","Regina","Mariana"], ["Hernandez","Lopez","Ramirez","Torres","Vargas","Morales"]),
        ("Japan", "Japanese, English", ["Tokyo", "Osaka", "Kyoto"], ["Haruto","Kenji","Takashi","Hiroshi","Daiki","Ryota"], ["Yuki","Sakura","Haruka","Aiko","Mio","Emi"], ["Tanaka","Watanabe","Yamamoto","Nakamura","Kobayashi","Saito"]),
        ("South Korea", "Korean, English", ["Seoul", "Busan", "Incheon"], ["Minjun","Seojun","Jihoon","Hyunwoo","Dongwoo","Taeyang"], ["Soyeon","Jiwoo","Haeun","Yuna","Minseo","Chaewon"], ["Kim","Park","Choi","Jung","Kang","Yoon"]),
        ("China", "Mandarin, English", ["Beijing", "Shanghai", "Shenzhen"], ["Wei","Jun","Hao","Lei","Bo","Ming"], ["Mei","Xiu","Lan","Jing","Ying","Fang"], ["Wang","Li","Zhang","Chen","Liu","Zhou"]),
        ("Thailand", "Thai, English", ["Bangkok", "Chiang Mai", "Phuket"], ["Somchai","Anan","Kittipong","Nattapong","Chaiwat","Prasert"], ["Siriporn","Malee","Napat","Pimchanok","Ratchanee","Suda"], ["Wongsakul","Chaiyasit","Srisai","Boonmee","Rattanakul","Thongchai"]),
        ("Indonesia", "Indonesian, English", ["Jakarta", "Bandung", "Surabaya"], ["Budi","Agus","Rizky","Dimas","Hendra","Wahyu"], ["Sari","Putri","Dewi","Ayu","Rina","Intan"], ["Pratama","Santoso","Wijaya","Hidayat","Nugroho","Saputra"]),
    ]
    # hospital naming per specialization (suffix is added after the city)
    HOSP_SUFFIX = {
        "Cardiology": ["Heart & Vascular Institute", "Cardiac Centre", "Heart Hospital"],
        "Dentistry": ["Dental Clinic", "Smile Centre", "Oral Health Institute"],
        "Dermatology": ["Skin Clinic", "Dermatology Centre", "Skin & Laser Hospital"],
        "Endocrinology": ["Diabetes & Endocrine Centre", "Hormone Clinic", "Endocrine Hospital"],
        "Gastroenterology": ["Digestive Health Centre", "Gastro Hospital", "GI Institute"],
        "General Medicine": ["General Hospital", "Family Care Clinic", "Medical Centre"],
        "Gynecology": ["Women's Hospital", "Women's Health Centre", "Maternity Clinic"],
        "Neurology": ["Neuroscience Institute", "Brain & Spine Centre", "Neurology Hospital"],
        "Oncology": ["Cancer Centre", "Oncology Institute", "Cancer Hospital"],
        "Ophthalmology": ["Eye Hospital", "Vision Centre", "Eye Institute"],
        "Orthopedics": ["Orthopaedic Hospital", "Bone & Joint Centre", "Sports Medicine Clinic"],
        "Pediatrics": ["Children's Hospital", "Kids Care Centre", "Paediatric Clinic"],
        "Psychiatry": ["Mind Care Clinic", "Mental Health Centre", "Behavioural Health Institute"],
        "Pulmonology": ["Lung & Respiratory Centre", "Chest Hospital", "Pulmonary Institute"],
        "Urology": ["Urology Centre", "Kidney & Urology Hospital", "Urology Clinic"],
    }
    used_names = set()
    _photo_count = {"men": 0, "women": 0}

    def portrait(gender):
        """Next white-coat doctor photo from static/images/doctors/men|women (no repeats until the folder is used up)."""
        from database.helpers import photo_pool
        kind = "women" if gender == "Female" else "men"
        pool = photo_pool(gender)
        n = _photo_count[kind]
        _photo_count[kind] += 1
        return pool[n % len(pool)] if pool else ""

    def pick_person(doc_idx, gender):
        """Country-matched unique (first, last, country-tuple) for doctors 11..150; first 10 keep legacy demo names."""
        country = COUNTRIES[doc_idx % len(COUNTRIES)]
        k = doc_idx // len(COUNTRIES)
        firsts = country[3] if gender == "Male" else country[4]
        first = firsts[k % len(firsts)]
        last = country[5][(k * 5 + (1 if gender == "Female" else 0)) % len(country[5])]
        used_names.add((first, last))
        return country, first, last

    spec_data = {
        "Cardiology": (["MBBS, MD Cardiology","MBBS, DNB Cardiology","MBBS, DM Cardiology","MBBS, MCh Cardiology"], ["AIIMS Heart Institute Delhi","Fortis Cardiac Centre Bangalore","Medanta Heart Institute Gurgaon","Apollo Hospitals Chennai","Max Heart Institute Delhi","Sri Venkateshwara Hospital Chennai","Lilavati Hospital Mumbai","Narayana Health Bangalore","Wockhardt Hospital Mumbai","Kokilaben Hospital Mumbai"], ["Interventional cardiology","Heart attack treatment","Angioplasty","Heart failure management","Echocardiography","Preventive cardiology","Women heart health","Hypertension","Arrhythmia","Coronary artery disease"], ["Delhi","Bangalore","Gurgaon","Chennai","Mumbai","Pune","Hyderabad","Kolkata","Jaipur","Ahmedabad"]),
        "Dentistry": (["BDS, MDS Conservative Dentistry","BDS, MDS Oral Surgery","BDS, MDS Orthodontics","BDS, MDS Periodontics"], ["BrightSmile Dental Clinic Mumbai","ImplantCare Dental Centre Mumbai","SmilePerfect Dental Delhi","DentalCare Hospital Pune","PerfectTeeth Clinic Chennai","OralHealth Centre Bangalore","ToothCare Hospital Kolkata","BrightDental Hyderabad","SmileHub Kochi","DentalPro Trivandrum"], ["General dentistry","Cosmetic dentistry","Root canal treatment","Teeth whitening","Braces and alignment","Dental implants","Wisdom tooth extraction","Bone grafting","Periodontics","Prosthodontics"], ["Mumbai","Delhi","Pune","Chennai","Bangalore","Kolkata","Hyderabad","Kochi","Trivandrum","Jaipur"]),
        "Dermatology": (["MBBS, MD Dermatology","MBBS, DNB Dermatology","MBBS, MD Venereology"], ["SkinCare Clinic Chennai","DermaCare Clinic Delhi","Dermatology Centre Bangalore","SkinHealth Hospital Mumbai","DermPerfect Pune","ClearSkin Clinic Hyderabad","GlowDerm Kolkata","SkinMed Chennai","DermaPlus Mumbai","Complexion Care Bangalore"], ["Skin disorders","Hair loss treatment","Acne and eczema","Aesthetic dermatology","Laser treatments","Psoriasis","Skin cancer screening","Anti-aging treatments","Chemical peels","Microneedling"], ["Chennai","Delhi","Bangalore","Mumbai","Pune","Hyderabad","Kolkata","Chennai","Mumbai","Bangalore"]),
        "Endocrinology": (["MBBS, MD Endocrinology","MBBS, DNB Endocrinology","MBBS, DM Endocrinology"], ["EndoCare Hospital Delhi","HormoneHealth Centre Delhi","ThyroidCare Clinic Mumbai","DiabetesCentre Bangalore","EndocrinePlus Kolkata","Hormona Hospital Chennai","CareEndo Pune","SugarCare Hyderabad","ThyroidPlus Kolkata","GlandCare Mumbai"], ["Diabetes management","Thyroid disorders","Hormonal imbalances","Osteoporosis","PCOS","Metabolic syndrome","Hormone replacement therapy","Growth disorders","Adrenal disorders","Pituitary disorders"], ["Delhi","Delhi","Mumbai","Bangalore","Kolkata","Chennai","Pune","Hyderabad","Kolkata","Mumbai"]),
        "Gastroenterology": (["MBBS, MD Gastroenterology","MBBS, DNB Gastroenterology","MBBS, DM Gastroenterology"], ["GastroCare Hospital Mumbai","DigestiveCare Centre Mumbai","GIHealth Hospital Delhi","StomachCare Bangalore","DigestPlus Pune","GI Clinic Chennai","GastroPlus Kolkata","ColonCare Hyderabad","BowelHealth Mumbai","DigestiveZone Chennai"], ["Liver diseases","IBS","Endoscopic procedures","Acid reflux","Colorectal health","Gastrointestinal cancer","Crohn disease","Ulcerative colitis","Celiac disease","Hepatitis"], ["Mumbai","Mumbai","Delhi","Bangalore","Pune","Chennai","Kolkata","Hyderabad","Mumbai","Chennai"]),
        "General Medicine": (["MBBS, MD General Medicine","MBBS, DNB General Medicine","MBBS, MD Internal Medicine"], ["Bangalore General Hospital","Mumbai Family Care Clinic","CityMed Hospital Delhi","PrimeCare Hyderabad","MetroHealth Kolkata","WellnessPlus Chennai","GeneralCare Mumbai","FamilyMed Pune","CoreHealth Bangalore","VitalCare Mumbai"], ["Preventive medicine","Diabetes management","Hypertension","Chronic disease management","Internal medicine","Family healthcare","Cardiovascular health","Respiratory health","Nutritional disorders","Geriatric medicine"], ["Bangalore","Mumbai","Delhi","Hyderabad","Kolkata","Chennai","Mumbai","Pune","Bangalore","Mumbai"]),
        "Gynecology": (["MBBS, MD Obstetrics & Gynecology","MBBS, DNB Gynecology","MBBS, MS Gynecology"], ["WomenCare Hospital Chennai","PCOS & Women Care Hospital Chennai","MaternityCare Mumbai","GynaePlus Bangalore","LadyCare Hospital Delhi","WomenHealth Kolkata","GynaecPlus Pune","MotherCare Hyderabad","FemiCare Mumbai","LadyWell Chennai"], ["Prenatal care","Gynecologic surgery","PCOS","Fertility","Menopause management","Contraception","HPV and cervical cancer","Fibroids","Endometriosis","High-risk pregnancy"], ["Chennai","Chennai","Mumbai","Bangalore","Delhi","Kolkata","Pune","Hyderabad","Mumbai","Chennai"]),
        "Neurology": (["MBBS, MD, DM Neurology","MBBS, MD Neurology","MBBS, DNB Neurology"], ["NeuroCare Institute Kolkata","NeuroScience Centre Kolkata","BrainHealth Hospital Mumbai","NeuroPlus Delhi","MindBrain Bangalore","NeuroCare Chennai","BrainCentre Hyderabad","NerveHealth Pune","NeuroPath Mumbai","BrainCare Kolkata"], ["Stroke care","Epilepsy","Movement disorders","Neuropathy","Migraine","Neuromodulation","Multiple sclerosis","Parkinson disease","Alzheimer disease","Brain tumors"], ["Kolkata","Kolkata","Mumbai","Delhi","Bangalore","Chennai","Hyderabad","Pune","Mumbai","Kolkata"]),
        "Oncology": (["MBBS, MD Oncology","MBBS, DM Oncology","MBBS, DNB Oncology"], ["OncoCare Hospital Mumbai","Breast Cancer Centre Mumbai","CancerCare Delhi","TumorInstitute Bangalore","OncologyPlus Chennai","CancerCentre Kolkata","OncMax Hyderabad","CancerCare Pune","MahaCancer Mumbai","LifeCare Oncology Chennai"], ["Medical oncology","Chemotherapy","Immunotherapy","Targeted therapy","Breast cancer","Gynecologic oncology","Lung cancer","Colorectal cancer","Prostate cancer","Skin cancer"], ["Mumbai","Mumbai","Delhi","Bangalore","Chennai","Kolkata","Hyderabad","Pune","Mumbai","Chennai"]),
        "Ophthalmology": (["MBBS, MS Ophthalmology","MBBS, DNB Ophthalmology","MBBS, MD Ophthalmology"], ["EyeCare Vision Centre Bangalore","VisionPlus Eye Hospital Bangalore","EyeHealth Hospital Mumbai","OcuPlus Delhi","SightCare Chennai","VisionCentre Kolkata","EyePlus Pune","OptiCare Hyderabad","EyeVision Mumbai","ClearSight Chennai"], ["Cataract surgery","LASIK","Retinal disorders","Glaucoma","Eye checkups","Corneal surgery","Pediatric eye care","Retinal surgery","Optometry","Dry eye syndrome"], ["Bangalore","Bangalore","Mumbai","Delhi","Chennai","Kolkata","Pune","Hyderabad","Mumbai","Chennai"]),
        "Orthopedics": (["MBBS, MS Orthopedics","MBBS, DNB Orthopedics","MBBS, MCh Orthopedics"], ["OrthoPlus Hospital Pune","OrthoCare Hospital Pune","JointCare Hospital Mumbai","BoneHealth Delhi","OrthoPlus Chennai","BoneMed Bangalore","OrthoPro Kolkata","JointPlus Hyderabad","BoneCare Mumbai","OrthoWell Pune"], ["Joint replacement","Sports medicine","Arthroscopy","Spine surgery","Trauma","Pediatric orthopedics","Joint preservation","Shoulder surgery","Knee surgery","Hip surgery"], ["Pune","Pune","Mumbai","Delhi","Chennai","Bangalore","Kolkata","Hyderabad","Mumbai","Pune"]),
        "Pediatrics": (["MBBS, MD Pediatrics","MBBS, DNB Pediatrics","MBBS, MD Neonatology"], ["KidCare Hospital Hyderabad","LittleStars Pediatric Centre Hyderabad","ChildrenCare Mumbai","BabyHealth Delhi","PedPlus Bangalore","KidZone Chennai","ChildFirst Kolkata","LittleMed Pune","BabyPlus Mumbai","KidCare Chennai"], ["Neonatal care","Childhood asthma","Nutritional disorders","Vaccinations","Developmental disorders","Childhood infections","Pediatric emergencies","Adolescent medicine","Congenital disorders","Respiratory disorders"], ["Hyderabad","Hyderabad","Mumbai","Delhi","Bangalore","Chennai","Kolkata","Pune","Mumbai","Chennai"]),
        "Psychiatry": (["MBBS, MD Psychiatry","MBBS, DNB Psychiatry","MBBS, MD Clinical Psychology"], ["MindCare Clinic Kolkata","Women MindCare Centre Kolkata","BrainMind Hospital Mumbai","PsychPlus Delhi","MentalHealth Bangalore","PsychCare Chennai","MindWell Kolkata","TherapyPlus Pune","PsychHub Mumbai","MindBridge Chennai"], ["Anxiety disorders","Depression","CBT","Stress management","PTSD","Women mental health","Trauma recovery","Addiction","ADHD","Bipolar disorder"], ["Kolkata","Kolkata","Mumbai","Delhi","Bangalore","Chennai","Kolkata","Pune","Mumbai","Chennai"]),
        "Pulmonology": (["MBBS, MD Pulmonology","MBBS, DNB Pulmonology","MBBS, DM Pulmonology"], ["LungCare Hospital Kolkata","LungHealth Clinic Kolkata","RespiratoryPlus Mumbai","BreathCare Delhi","PulmonaryBangalore","LungMed Chennai","AirwayCare Hyderabad","LungPro Pune","BreatheWell Mumbai","LungHealth Chennai"], ["Respiratory diseases","Asthma management","COPD","TB treatment","ICU respiratory care","Interventional pulmonology","Sleep apnea","Allergic respiratory","Pulmonary fibrosis","Bronchoscopy"], ["Kolkata","Kolkata","Mumbai","Delhi","Bangalore","Chennai","Hyderabad","Pune","Mumbai","Chennai"]),
        "Urology": (["MBBS, MS, MCh Urology","MBBS, MS Urology","MBBS, DNB Urology"], ["UroCare Hospital Delhi","Women Urology Centre Delhi","UroPlus Mumbai","KidneyCare Bangalore","UroHealth Chennai","BladderPlus Kolkata","UroPro Hyderabad","RenalCare Pune","UroMed Mumbai","UroWell Chennai"], ["Kidney stones","Prostate disorders","Robotic surgery","Bladder disorders","Female urology","Urinary incontinence","Minimally invasive procedures","UTIs","Erectile dysfunction","Renal transplant"], ["Delhi","Delhi","Mumbai","Bangalore","Chennai","Kolkata","Hyderabad","Pune","Mumbai","Chennai"]),
    }

    # Generate doctor records
    LEGACY = ["Rahul Sharma", "Sunita Patil", "Vikram Mehra", "Ananya Reddy", "Rajesh Gupta",
              "Swetha Singh", "Amit Kumar", "Deepa Das", "Vikas Mishra", "Shweta Iyer"]   # demo logins used by README / tests
    doctors_list = []
    doc_idx = 0
    for spec_name, (quals, hospitals, expertise_list, cities) in spec_data.items():
        for i in range(10):
            gender = "Male" if i % 2 == 0 else "Female"
            if doc_idx < 10:   # original 10 demo doctors keep their names, e-mails and Indian hospitals
                first, last = LEGACY[doc_idx].split()
                country_name, langs, city, hospital = "India", ["Hindi, English", "English", "Tamil, English", "Telugu, English", "Bengali, English", "Marathi, English", "Kannada, English", "Gujarati, English", "Punjabi, English", "Urdu, English"][i], cities[i % len(cities)], hospitals[i % len(hospitals)]
                qual = quals[i % len(quals)]
                email = f"{first.lower()}.dr.@health.com"
            else:
                country, first, last = pick_person(doc_idx, gender)
                country_name, langs = country[0], country[1]
                city = country[2][(doc_idx // len(COUNTRIES) + i) % 3]
                hospital = f"{city} {HOSP_SUFFIX[spec_name][(doc_idx // 3) % 3]}"
                qual = quals[i % len(quals)]
                if country_name != "India":
                    qual = qual.replace("MBBS, ", "").replace("BDS, ", "DDS, ")
                email = f"{first.lower().replace(' ', '')}.{last.lower().replace(' ', '')}@health.com"
            name = f"Dr. {first} {last}"
            image = portrait(gender)      # real doctor photo (white coat + stethoscope)
            exp_list = [3, 5, 7, 8, 10, 12, 15, 18, 20, 22]
            fee_list = [249, 299, 349, 399, 449, 499]
            days_list = ["Mon-Fri", "Mon-Wed-Fri", "Tue-Thu-Sat", "Mon-Tue-Thu", "Mon-Wed-Sat"]
            time_list = ["10:00 AM - 1:00 PM, 4:00 PM - 7:00 PM", "9:00 AM - 1:00 PM, 5:00 PM - 8:00 PM", "9:00 AM - 1:00 PM, 3:00 PM - 6:00 PM"]
            mode_list = ["In-person", "Telehealth"]
            doc = (name, email, f"98765{43200 + doc_idx:05d}",
                   f"{1960 + (doc_idx % 25):04d}-{((doc_idx % 12) + 1):02d}-{((doc_idx % 28) + 1):02d}",
                   gender, f"{30 + doc_idx*5} Main Street, {city}, {country_name}", spec_name,
                   qual, exp_list[i % len(exp_list)], fee_list[i % len(fee_list)],
                   f"{spec_name} specialist from {country_name} with {exp_list[i % len(exp_list)]} years of clinical experience. Expert in {expertise_list[i % len(expertise_list)]}. Providing compassionate patient care at {hospital}.",
                   4.5 + (i % 5) * 0.1, days_list[i % len(days_list)],
                   time_list[i % len(time_list)], hospital,
                   langs, expertise_list[i % len(expertise_list)],
                   f"{first} {last} is a dedicated {spec_name.lower()} specialist based in {city}, {country_name}, with {exp_list[i % len(exp_list)]} years of experience. Passionate about delivering exceptional healthcare outcomes.",
                   mode_list[i % len(mode_list)],
                   image)
            doctors_list.append(doc)
            doc_idx += 1

    c.execute("DELETE FROM doctors")
    c.execute("DELETE FROM users WHERE role='doctor'")
    conn.commit()

    for doctor in doctors_list:
        name, email, mobile, dob, gender, addr, spec_name, qual, exp, fee, about, rating, avail_days, avail_time, hospital, languages, expertise, bio, consult_mode, image = doctor
        c.execute("SELECT id FROM specializations WHERE name = ?", (spec_name,))
        spec = c.fetchone()
        spec_id = spec["id"] if spec else None
        hashed = hash_password("password123")
        c.execute("INSERT OR IGNORE INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                   (name, email, mobile, dob, gender, addr, hashed, "doctor"))
        c.execute("SELECT id FROM users WHERE email = ?", (email,))
        user = c.fetchone()
        if user:
            c.execute("""INSERT OR IGNORE INTO doctors (user_id, specialization_id, qualification, experience, consultation_fee, about, rating, available_days, available_time, image, hospital, languages, expertise, gender, bio, consultation_mode)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                      (user["id"], spec_id, qual, exp, fee, about, rating, avail_days, avail_time, image, hospital, languages, expertise, gender, bio, consult_mode))

    conn.commit()
    c.execute("SELECT COUNT(*) FROM doctors")
    print(f"Total doctors: {c.fetchone()[0]}")
    c.execute("SELECT s.name, COUNT(d.id) FROM specializations s LEFT JOIN doctors d ON s.id = d.specialization_id GROUP BY s.name ORDER BY s.name")
    for r in c.fetchall():
        print(f"  {r[0]}: {r[1]}")

    demo_patients = [
        ('Alice Johnson', 'alice.j@email.com', '5551234567', '1990-05-15', 'Female', '100 Patient St, NY', 'A+', 'Penicillin', '555-9876'),
        ('Bob Smith', 'bob.s@email.com', '5551234568', '1985-08-22', 'Male', '200 Patient Ave, CA', 'O+', '', '555-8765'),
        ('Carol White', 'carol.w@email.com', '5551234569', '1995-12-03', 'Female', '300 Patient Rd, TX', 'B-', 'Shellfish', '555-7654'),
        ('Daniel Lee', 'daniel.l@email.com', '5551234570', '1978-03-28', 'Male', '400 Patient Blvd, FL', 'AB+', '', '555-6543'),
        ('Eva Martinez', 'eva.m@email.com', '5551234571', '2000-07-11', 'Female', '500 Patient Ln, IL', 'A-', 'Latex', '555-5432'),
    ]

    for name, email, mobile, dob, gender, addr, bg, allergies, emerg in demo_patients:
        hashed = hash_password('password123')
        try:
            c.execute('INSERT OR IGNORE INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                       (name, email, mobile, dob, gender, addr, hashed, 'patient'))
            c.execute('SELECT id FROM users WHERE email = ?', (email,))
            user = c.fetchone()
            if user:
                c.execute('INSERT OR IGNORE INTO patients (user_id, blood_group, allergies, emergency_contact) VALUES (?, ?, ?, ?)',
                           (user['id'], bg, allergies, emerg))
        except sqlite3.IntegrityError:
            pass

    c.execute('SELECT id FROM users WHERE role = "patient"')
    all_patients = c.fetchall()
    c.execute('SELECT id FROM users WHERE role = "doctor"')
    all_doctors = c.fetchall()

    now = datetime.now()
    for i, patient in enumerate(all_patients[:3]):
        doctor = all_doctors[i % len(all_doctors)]
        appt_date = (now + timedelta(days=(i+1)*3)).strftime('%Y-%m-%d')
        appt_time = ['09:00', '10:00', '11:00', '14:00'][i % 4]
        reasons = ['Regular checkup', 'Follow-up consultation', 'Blood pressure screening', 'Skin examination', 'Annual physical']
        c.execute('INSERT OR IGNORE INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?, ?)',
                   (patient['id'], doctor['id'], appt_date, appt_time, reasons[i % len(reasons)], 'confirmed' if i == 0 else 'pending'))

    if all_patients and all_doctors:
        c.execute('INSERT OR IGNORE INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, symptoms, treatment, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
                   (all_patients[0]['id'], all_doctors[0]['id'], (now - timedelta(days=30)).strftime('%Y-%m-%d'), 'Hypertension', 'Frequent headaches, dizziness', 'Lifestyle modification and medication', 'Patient advised to reduce salt intake'))
        c.execute('INSERT OR IGNORE INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, symptoms, treatment, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
                   (all_patients[1]['id'], all_doctors[1]['id'], (now - timedelta(days=60)).strftime('%Y-%m-%d'), 'Migraine', 'Severe headaches with nausea', 'Prescribed medication and rest', 'Patient responding well to treatment'))

        c.execute('INSERT OR IGNORE INTO prescriptions (patient_id, doctor_id, medicine_name, dosage, frequency, duration, instructions, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   (all_patients[0]['id'], all_doctors[0]['id'], 'Lisinopril', '10mg', 'Once daily', '30 days', 'Take with food', (now - timedelta(days=15)).strftime('%Y-%m-%d')))
        c.execute('INSERT OR IGNORE INTO prescriptions (patient_id, doctor_id, medicine_name, dosage, frequency, duration, instructions, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   (all_patients[1]['id'], all_doctors[1]['id'], 'Sumatriptan', '50mg', 'As needed', '14 days', 'Take at onset of migraine', (now - timedelta(days=45)).strftime('%Y-%m-%d')))

        c.execute('INSERT OR IGNORE INTO lab_reports (test_name, patient_id, doctor_id, test_date, result, reference_range, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   ('Complete Blood Count', all_patients[0]['id'], all_doctors[0]['id'], (now - timedelta(days=10)).strftime('%Y-%m-%d'), 'Normal', '4.5-5.5 x 10^6 cells/mcL', 'Normal', 'All parameters within normal range'))
        c.execute('INSERT OR IGNORE INTO lab_reports (test_name, patient_id, doctor_id, test_date, result, reference_range, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   ('Blood Glucose', all_patients[1]['id'], all_doctors[1]['id'], (now - timedelta(days=20)).strftime('%Y-%m-%d'), '95 mg/dL', '70-100 mg/dL', 'Normal', 'Fasting glucose within normal range'))
        c.execute('INSERT OR IGNORE INTO lab_reports (test_name, patient_id, doctor_id, test_date, result, reference_range, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   ('Cholesterol Panel', all_patients[0]['id'], all_doctors[0]['id'], (now - timedelta(days=40)).strftime('%Y-%m-%d'), '200 mg/dL', '<200 mg/dL', 'Borderline High', 'Dietary modifications recommended'))

    c.execute('SELECT id FROM users WHERE role = "patient"')
    for patient in c.fetchall():
        c.execute('INSERT OR IGNORE INTO notifications (user_id, title, message) VALUES (?, ?, ?)', (patient['id'], 'Welcome to NextGen Healthcare', 'Your account has been created successfully!'))
        c.execute('INSERT OR IGNORE INTO notifications (user_id, title, message) VALUES (?, ?, ?)', (patient['id'], 'Appointment Reminder', 'You have an upcoming appointment scheduled.'))

    c.execute('SELECT id FROM users WHERE role = "doctor"')
    for doctor in c.fetchall():
        c.execute('INSERT OR IGNORE INTO notifications (user_id, title, message) VALUES (?, ?, ?)', (doctor['id'], 'New Appointment', 'You have a new appointment request.'))

    # Create default admin account if not exists
    c.execute('SELECT id FROM users WHERE email = ?', ('admin@health.com',))
    if not c.fetchone():
        admin_hashed = hash_password('password123')
        c.execute('INSERT INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   ('System Admin', 'admin@health.com', '0000000000', '1980-01-01', 'Male', 'Admin Office, HQ', admin_hashed, 'admin'))
        print('Default admin account created: admin@health.com / password123')

    conn.commit()
    conn.close()
    print(f'Database initialized successfully at {DB_PATH}')

if __name__ == '__main__':
    init_db()
