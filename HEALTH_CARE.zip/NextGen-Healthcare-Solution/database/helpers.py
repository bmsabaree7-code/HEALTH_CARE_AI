"""DB migrations + demo data used on every start-up (idempotent)."""
import os
import random
from collections import Counter
from datetime import datetime, timedelta

PHOTO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'static', 'images', 'doctors')
PHOTO_URL = '/static/images/doctors'
PHOTO_EXT = ('.jpg', '.jpeg', '.png', '.webp')
OLD_PHOTO_HOSTS = ('randomuser.me', 'images.unsplash.com')


def photo_pool(gender):
    """URLs of every photo in static/images/doctors/men (or women), in a fixed shuffled order."""
    kind = 'women' if (gender or '').lower().startswith('f') else 'men'
    folder = os.path.join(PHOTO_DIR, kind)
    if not os.path.isdir(folder):
        return []
    files = sorted(f for f in os.listdir(folder) if f.lower().endswith(PHOTO_EXT))
    random.Random(2024).shuffle(files)       # fixed mix, so neighbouring doctors look different
    return [f'{PHOTO_URL}/{kind}/{f}' for f in files]


def is_pool_photo(url):
    return (url or '').startswith(PHOTO_URL + '/') and not url.endswith('.svg')


def is_stale_photo(url):
    """True for empty photos, the old stock-photo links, and pool photos whose file was deleted."""
    if not url:
        return True
    if url.startswith(('http://', 'https://')):
        return any(h in url for h in OLD_PHOTO_HOSTS)
    if is_pool_photo(url):
        return not os.path.exists(os.path.join(PHOTO_DIR, '..', '..', url[len('/static/'):]))
    return False


def pick_from_pool(gender, usage):
    """Least-used photo for this gender: unique until every photo is used once, then it starts a second round."""
    pool = photo_pool(gender)
    if not pool:
        return ''
    return min(pool, key=lambda u: usage.get(u, 0))


def pick_photo(conn, gender):
    """Next free pool photo, taking the doctors already in the database into account."""
    usage = Counter(r[0] for r in conn.execute('SELECT image FROM doctors WHERE image IS NOT NULL'))
    return pick_from_pool(gender, usage)



def migrate(conn):
    """Add missing columns / fix doctor photos. Safe to run many times."""
    # 1. appointments.consultation_mode  (booking crashed without this column)
    cols = [r[1] for r in conn.execute('PRAGMA table_info(appointments)').fetchall()]
    if 'consultation_mode' not in cols:
        conn.execute("ALTER TABLE appointments ADD COLUMN consultation_mode TEXT DEFAULT 'In-person'")

    # 2. doctors table: remember how a doctor joined ('seed' = demo data, 'registered' = signed up / added later)
    dcols = [r[1] for r in conn.execute('PRAGMA table_info(doctors)').fetchall()]
    if 'source' not in dcols:
        conn.execute("ALTER TABLE doctors ADD COLUMN source TEXT DEFAULT 'seed'")
    # one profile row per doctor account (older databases had the same 10 doctors repeated)
    conn.execute('DELETE FROM doctors WHERE id NOT IN (SELECT MIN(id) FROM doctors GROUP BY user_id)')

    # 3. doctor photos: old stock/avatar links (randomuser.me, unsplash) are removed and every doctor gets a
    #    photo from static/images/doctors/men|women (white coat + stethoscope). Photos are handed out so that
    #    nobody repeats until the whole folder has been used. Uploaded photos are never touched.
    rows = conn.execute('''SELECT d.id, d.image, d.gender, u.gender AS ugender
                           FROM doctors d JOIN users u ON u.id = d.user_id ORDER BY d.id''').fetchall()
    usage = Counter(r['image'] for r in rows if r['image'] and is_pool_photo(r['image']))
    for r in rows:
        img = r['image'] or ''
        if img and not is_stale_photo(img):
            continue
        gender = (r['gender'] or r['ugender'] or 'Male').strip()
        gender = 'Female' if gender.lower().startswith('f') else 'Male'
        if img in usage:
            usage[img] -= 1
        new = pick_from_pool(gender, usage)
        if new:
            usage[new] += 1
        conn.execute('UPDATE doctors SET image = ?, gender = ? WHERE id = ?', (new, gender, r['id']))
    conn.commit()


def _uid(conn, email):
    row = conn.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()
    return row['id'] if row else None


def seed_patient_records(conn):
    """Demo medical records / prescriptions / lab reports so every patient has a full history."""
    now = datetime.now()
    d = lambda days: (now - timedelta(days=days)).strftime('%Y-%m-%d')

    docs = {n: _uid(conn, f'{n}.dr.@health.com') for n in ['rahul', 'sunita', 'vikram', 'ananya', 'rajesh']}
    pts = {n: _uid(conn, e) for n, e in [('alice', 'alice.j@email.com'), ('bob', 'bob.s@email.com'),
                                         ('carol', 'carol.w@email.com'), ('daniel', 'daniel.l@email.com'),
                                         ('eva', 'eva.m@email.com')]}
    if not all(docs.values()) or not all(pts.values()):
        return

    records = [  # patient, doctor, days_ago, diagnosis, symptoms, treatment, notes
        ('alice', 'rahul', 30, 'Hypertension', 'Frequent headaches, dizziness', 'Lifestyle modification and medication', 'Reduce salt intake; review BP in 4 weeks'),
        ('alice', 'rahul', 75, 'Seasonal allergic rhinitis', 'Sneezing, watery eyes', 'Antihistamine course', 'Avoid dust exposure'),
        ('alice', 'sunita', 140, 'Vitamin D deficiency', 'Fatigue, body ache', 'Vitamin D3 supplementation', 'Repeat test after 3 months'),
        ('bob', 'rahul', 20, 'Type 2 Diabetes (early)', 'Increased thirst, frequent urination', 'Diet control + Metformin', 'Walk 30 min daily'),
        ('bob', 'sunita', 60, 'Migraine', 'Severe headaches with nausea', 'Prescribed medication and rest', 'Responding well to treatment'),
        ('carol', 'rahul', 12, 'Iron-deficiency anemia', 'Weakness, pale skin', 'Iron + folic acid tablets', 'Eat iron-rich foods; recheck Hb in 6 weeks'),
        ('carol', 'vikram', 50, 'Mild asthma', 'Wheezing at night', 'Inhaler as needed', 'Avoid cold exposure and smoke'),
        ('daniel', 'ananya', 25, 'Lower back strain', 'Back pain after lifting', 'Physiotherapy + muscle relaxant', 'Avoid heavy lifting for 2 weeks'),
        ('daniel', 'vikram', 90, 'High cholesterol', 'No symptoms (routine check)', 'Diet change + statin', 'Lipid profile in 3 months'),
        ('eva', 'ananya', 18, 'Viral fever', 'Fever, sore throat, body ache', 'Rest, fluids, paracetamol', 'Review if fever persists > 3 days'),
        ('eva', 'rajesh', 70, 'Acne vulgaris', 'Facial breakouts', 'Topical retinoid + cleanser', 'Use sunscreen daily'),
    ]
    prescriptions = [  # patient, doctor, medicine, dosage, freq, duration, instructions, days_ago
        ('alice', 'rahul', 'Amlodipine', '5mg', 'Once daily', '30 days', 'Take in the morning', 15),
        ('alice', 'rahul', 'Cetirizine', '10mg', 'Once at night', '7 days', 'May cause drowsiness', 75),
        ('bob', 'rahul', 'Metformin', '500mg', 'Twice daily', '30 days', 'Take after meals', 20),
        ('bob', 'sunita', 'Sumatriptan', '50mg', 'As needed', '14 days', 'Take at onset of migraine', 60),
        ('carol', 'rahul', 'Ferrous Sulfate + Folic Acid', '1 tablet', 'Once daily', '45 days', 'Take after food', 12),
        ('carol', 'vikram', 'Salbutamol Inhaler', '2 puffs', 'As needed', '30 days', 'Rinse mouth after use', 50),
        ('daniel', 'ananya', 'Thiocolchicoside', '4mg', 'Twice daily', '5 days', 'Take after food', 25),
        ('daniel', 'vikram', 'Atorvastatin', '10mg', 'Once at night', '90 days', 'Avoid grapefruit', 90),
        ('eva', 'ananya', 'Paracetamol', '500mg', 'Every 6 hours', '3 days', 'Only if fever > 100F', 18),
        ('eva', 'rajesh', 'Adapalene Gel 0.1%', 'Thin layer', 'Once at night', '60 days', 'Apply on clean dry skin', 70),
    ]
    labs = [  # test, patient, doctor, days_ago, result, range, status, remarks
        ('Complete Blood Count', 'alice', 'rahul', 10, 'Normal', '4.5-5.5 x 10^6 cells/mcL', 'Normal', 'All parameters within normal range'),
        ('Cholesterol Panel', 'alice', 'rahul', 40, '200 mg/dL', '<200 mg/dL', 'Borderline High', 'Dietary modifications recommended'),
        ('Blood Pressure Monitoring', 'alice', 'rahul', 28, '138/88 mmHg', '<120/80 mmHg', 'Abnormal', 'Stage 1 hypertension - follow up'),
        ('Blood Glucose', 'bob', 'sunita', 20, '95 mg/dL', '70-100 mg/dL', 'Normal', 'Fasting glucose within normal range'),
        ('HbA1c', 'bob', 'rahul', 18, '6.9 %', '< 5.7 %', 'Abnormal', 'Diabetic range - start treatment'),
        ('Hemoglobin', 'carol', 'rahul', 11, '9.8 g/dL', '12.0-15.5 g/dL', 'Abnormal', 'Low hemoglobin - iron therapy advised'),
        ('Peak Flow / Spirometry', 'carol', 'vikram', 48, '78 % predicted', '> 80 % predicted', 'Borderline High', 'Mild airflow limitation'),
        ('Lipid Profile', 'daniel', 'vikram', 88, 'LDL 165 mg/dL', 'LDL < 100 mg/dL', 'Abnormal', 'High LDL - statin started'),
        ('Lumbar Spine X-Ray', 'daniel', 'ananya', 24, 'No fracture seen', 'N/A', 'Normal', 'Mild muscle spasm only'),
        ('Dengue NS1 Antigen', 'eva', 'ananya', 17, 'Negative', 'Negative', 'Normal', 'No dengue infection detected'),
        ('Thyroid Profile (TSH)', 'eva', 'rajesh', 68, '2.4 mIU/L', '0.4-4.0 mIU/L', 'Normal', 'Thyroid function normal'),
    ]
    extra_appts = [  # patient, doctor, days_from_now, time, reason, status, mode
        ('daniel', 'ananya', -25, '10:00 AM', 'Back pain consultation', 'completed', 'In-person'),
        ('eva', 'ananya', -18, '11:00 AM', 'Fever and sore throat', 'completed', 'Telehealth'),
        ('bob', 'rahul', -20, '09:30 AM', 'Diabetes screening', 'completed', 'In-person'),
        ('carol', 'rahul', -12, '04:30 PM', 'Weakness and tiredness', 'completed', 'In-person'),
        ('alice', 'rahul', 6, '10:30 AM', 'Blood pressure follow-up', 'confirmed', 'In-person'),
    ]

    for p, dr, ago, dx, sym, tr, notes in records:
        if not conn.execute('SELECT 1 FROM medical_records WHERE patient_id=? AND doctor_id=? AND diagnosis=?',
                            (pts[p], docs[dr], dx)).fetchone():
            conn.execute('''INSERT INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, symptoms, treatment, notes)
                            VALUES (?,?,?,?,?,?,?)''', (pts[p], docs[dr], d(ago), dx, sym, tr, notes))
    for p, dr, med, dose, freq, dur, ins, ago in prescriptions:
        if not conn.execute('SELECT 1 FROM prescriptions WHERE patient_id=? AND medicine_name=?', (pts[p], med)).fetchone():
            conn.execute('''INSERT INTO prescriptions (patient_id, doctor_id, medicine_name, dosage, frequency, duration, instructions, date)
                            VALUES (?,?,?,?,?,?,?,?)''', (pts[p], docs[dr], med, dose, freq, dur, ins, d(ago)))
    for test, p, dr, ago, res, rng, st, rem in labs:
        if not conn.execute('SELECT 1 FROM lab_reports WHERE patient_id=? AND test_name=?', (pts[p], test)).fetchone():
            conn.execute('''INSERT INTO lab_reports (test_name, patient_id, doctor_id, test_date, result, reference_range, status, remarks)
                            VALUES (?,?,?,?,?,?,?,?)''', (test, pts[p], docs[dr], d(ago), res, rng, st, rem))
    for p, dr, off, tm, reason, st, mode in extra_appts:
        date = (now + timedelta(days=off)).strftime('%Y-%m-%d')
        if not conn.execute('SELECT 1 FROM appointments WHERE patient_id=? AND doctor_id=? AND appointment_date=?',
                            (pts[p], docs[dr], date)).fetchone():
            conn.execute('''INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status, consultation_mode)
                            VALUES (?,?,?,?,?,?,?)''', (pts[p], docs[dr], date, tm, reason, st, mode))
    conn.commit()
