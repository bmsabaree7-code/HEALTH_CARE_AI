# NextGen Healthcare Solution

A comprehensive healthcare management web application built with Flask, SQLite, HTML5, CSS3, and JavaScript.

## Project Overview

NextGen Healthcare Solution is a full-featured healthcare management platform that enables patients, doctors, and administrators to manage healthcare services digitally. The application provides an integrated system for appointment booking, medical records management, prescription handling, lab reports, notifications, and more.

## Features

### Patient Module
- User registration and login with password hashing
- Profile management (view/edit)
- Search and filter doctors by name, specialization, availability, experience, and consultation fee
- Smart doctor recommendation system
- Book, view, and cancel appointments
- View medical records, prescriptions, and lab reports
- Notification system
- Emergency quick help
- Health report dashboard
- Medicine reminders

### Doctor Module
- Doctor login and profile management
- View today's appointments, pending, and completed
- Accept/reject/complete appointments
- View patient details and medical history
- Add medical records and prescriptions
- Add lab reports
- Notification system

### Admin Module
- Full user management (add/view/edit/delete patients and doctors)
- Appointment management (view/filter/update status)
- Specialization management (add/edit/delete)
- Medical record management
- Prescription management
- Lab report management
- System analytics dashboard

### Unique Features
- **Smart Doctor Recommendation**: Rule-based recommendation system that suggests doctors based on selected specialization
- **Advanced Search & Filter**: Filter doctors by name, specialization, availability, experience, and fee range
- **Appointment Availability System**: Real-time time slot management preventing double booking
- **Medicine Reminder**: Digital prescription tracking with dosage and frequency
- **Health Report Dashboard**: Comprehensive health summary for patients
- **Emergency Quick Help**: Quick access to emergency contacts and services

## Technologies

- **Python 3** - Backend programming
- **Flask** - Web framework
- **SQLite** - Database
- **HTML5** - Structure
- **CSS3** - Styling with modern healthcare theme
- **JavaScript** - Client-side interactivity
- **Jinja2** - Template engine
- **Font Awesome** - Icons
- **Google Fonts** - Typography (Inter)

## Folder Structure

```
NextGen-Healthcare-Solution/
├── app.py                    # Main Flask application
├── database.db               # SQLite database
├── requirements.txt          # Python dependencies
├── README.md                 # Project documentation
├── templates/                # HTML templates
│   ├── base.html            # Base template
│   ├── index.html           # Landing page
│   ├── login.html           # Login page
│   ├── register.html        # Registration page
│   ├── patient_dashboard.html
│   ├── doctor_dashboard.html
│   ├── admin_dashboard.html
│   ├── doctors.html         # Doctor listing
│   ├── doctor_details.html
│   ├── appointments.html
│   ├── medical_records.html
│   ├── prescriptions.html
│   ├── lab_reports.html
│   ├── notifications.html
│   ├── profile.html
│   ├── health_report.html
│   ├── smart_recommend.html
│   ├── emergency.html
│   ├── services.html
│   ├── about.html
│   ├── contact.html
│   ├── error.html
│   ├── admin_patients.html
│   ├── admin_doctors.html
│   ├── admin_records.html
│   ├── admin_prescriptions.html
│   ├── admin_lab_reports.html
│   └── services.html
├── static/                  # Static assets
│   ├── css/style.css        # Main stylesheet
│   ├── js/script.js         # JavaScript
│   └── images/              # Image assets
└── database/
    └── init_db.py           # Database initialization script
```

## Installation

1. Clone or download the project files
2. Navigate to the project directory
3. Install dependencies:
```bash
pip install -r requirements.txt
```
4. Initialize the database:
```bash
python database/init_db.py
```
5. Run the application:
```bash
python app.py
```

## Running the Application

```bash
python app.py
```

The application will start on `http://127.0.0.1:5000`

## Demo Credentials

The application comes with pre-populated demo accounts. All passwords are `password123`.

### Patient Account
- **Email**: alice.j@email.com
- **Password**: password123
- **Name**: Alice Johnson

### Doctor Account
- **Email**: sarah.johnson@health.com
- **Password**: password123
- **Name**: Dr. Sarah Johnson

### Admin Account
- **Email**: admin@health.com (if not present, create via code)
- **Password**: password123

To create an admin account, you can modify `init_db.py` or register a new user and update the role in the database.

## Main Modules

1. **Authentication System** - Registration, login, logout with password hashing
2. **Patient Dashboard** - Profile, appointments, notifications, lab reports
3. **Doctor Dashboard** - Appointments, medical records, prescriptions, lab reports
4. **Admin Dashboard** - User management, analytics, records management
5. **Doctor Search & Filter** - Advanced search with multiple filters
6. **Appointment System** - Booking, availability, status management
7. **Medical Records** - CRUD operations for medical records
8. **Prescription System** - Create and view prescriptions
9. **Lab Reports** - Upload and view lab test results
10. **Notification System** - In-app notifications with read/unread status
11. **Smart Recommendation** - Rule-based doctor recommendation
12. **Emergency Help** - Quick access to emergency contacts

## Security Features

- Password hashing using SHA-256
- Session-based authentication
- Role-based access control (Patient/Doctor/Admin)
- Parameterized SQL queries to prevent injection
- Input validation on all forms
- Unauthorized access prevention

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

MIT License - NextGen Healthcare Solution 2024


## What's new (latest update)

- **Doctor photos** - all 150 doctors have a unique real portrait photo (75 men + 75 women, from randomuser.me,
  people of many nationalities). No avatars / illustrations are used. Photos load from the internet.
- **Worldwide doctors** - 150 doctors from 25 countries; names, cities, hospitals and languages match the country.
- **Green success popup** - booking an appointment instantly shows a green
  "Appointment successfully registered!" toast, and a notification is added to the patient's bell.
  (Also fixed the crash that made booking fail: missing `appointments.consultation_mode` column,
  and the wrong appointment id on the confirmation page.)
- **Patient records** - doctors get **My Patients** -> click a patient -> full record page with
  Medical Records, Prescriptions, Lab Reports and Appointments (new ones can be added right there).
  Patients see their own page via **My Records**; admin via Patients -> View.
- `static/css/style.css` encoding corruption fixed (doctor-card styles now load properly).

## Run

```
pip install -r requirements.txt
python app.py          # http://127.0.0.1:5000
python test_full.py    # 63 automated checks (uses a temp copy of the DB)
```

## Demo logins (password for all: `password123`)

| Role    | Email                        |
|---------|------------------------------|
| Admin   | admin@health.com             |
| Doctor  | rahul.dr.@health.com         |
| Doctor  | ananya.dr.@health.com        |
| Patient | alice.j@email.com            |
| Patient | bob.s@email.com              |

## Doctor registration & photos
- `/register` has a **Patient / Doctor** switch. Doctors enter specialization, qualification, experience, fee, hospital, languages, about and can upload a photo (PNG/JPG/WEBP/GIF, max 3 MB).
- No photo uploaded → a gender-matched portrait photo is assigned automatically. Doctors can change/remove their photo from **Profile**; admins can upload a photo in **Add New Doctor**.
- Uploaded photos are stored in `static/uploads/doctors/`.
- Newly registered doctors appear (with a NEW badge and full details) at the top of `/doctors` and in the admin doctor list.
- Database now holds 150 distinct doctors (previously the same 10 names repeated).
