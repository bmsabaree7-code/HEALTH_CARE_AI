import urllib.request
r = urllib.request.urlopen('http://127.0.0.1:5000/doctors', timeout=3)
c = r.read().decode()
print('Status:', r.status)
import re
names = re.findall(r'Dr\.\s+[A-Za-z]+\s+[A-Za-z]+', c)
print(f'Total mentions: {len(names)}')
print(f'Unique names: {len(set(names))}')

# Test specialization filter
for spec in ['Cardiology', 'Dentistry', 'Pediatrics']:
    r = urllib.request.urlopen(f'http://127.0.0.1:5000/doctors?specialization={spec}', timeout=3)
    c = r.read().decode()
    print(f'{spec} filter: {c.count(spec)} mentions')

# Test gender filter
r = urllib.request.urlopen('http://127.0.0.1:5000/doctors?gender=Female', timeout=3)
c = r.read().decode()
names_f = re.findall(r'Dr\.\s+[A-Za-z]+\s+[A-Za-z]+', c)
print(f'Female filter: {len(names_f)} doctors')

# Test doctor details
r = urllib.request.urlopen('http://127.0.0.1:5000/doctor/1', timeout=3)
c = r.read().decode()
print(f'Doctor 1 page: status={r.status}, INR={chr(8377) in c}')

# Test search
r = urllib.request.urlopen('http://127.0.0.1:5000/doctors?q=Rahul', timeout=3)
c = r.read().decode()
print(f'Search Rahul: {len(re.findall(r"Dr\.\s+Rahul", c))} results')

print('\nAll tests complete!')
