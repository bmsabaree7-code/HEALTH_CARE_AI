import urllib.request, time, sys

time.sleep(2)  # Wait for server

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/')
    print('Home:', r.status)
except Exception as e:
    print('Home ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/services')
    print('Services:', r.status)
except Exception as e:
    print('Services ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/contact')
    print('Contact:', r.status)
except Exception as e:
    print('Contact ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/doctors')
    print('Doctors:', r.status)
except Exception as e:
    print('Doctors ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/emergency')
    print('Emergency:', r.status)
except Exception as e:
    print('Emergency ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/static/css/style.css')
    c = r.read().decode()
    print('CSS:', r.status, len(c), 'bytes')
    for cls in ['services-grid-large', 'service-card-large', 'contact-page', 'actions-bar', 'add-spec-form', '.text-warning', '.card', '.quick-actions']:
        print(f'  CSS has {cls}:', cls in c)
except Exception as e:
    print('CSS ERROR:', e)

print('\n--- Route checks ---')
try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/services')
    c = r.read().decode()
    print('Services page has service-card-large:', 'service-card-large' in c)
    print('Services page has services-grid-large:', 'services-grid-large' in c)
except Exception as e:
    print('Services page ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/contact')
    c = r.read().decode()
    print('Contact page has form action:', 'action=' in c)
    print('Contact page has method POST:', 'method="POST"' in c)
except Exception as e:
    print('Contact page ERROR:', e)

try:
    r = urllib.request.urlopen('http://127.0.0.1:5000/admin_doctors')
except:
    pass

print('\nAll tests complete.')
