import urllib.request
r = urllib.request.urlopen('http://127.0.0.1:5000/doctors', timeout=3)
c = r.read().decode()
print('Status:', r.status)

# Count doctor names
import re
names = re.findall(r'Dr\.\s+\w+\s+\w+', c)
print(f'Total mentions: {len(names)}')
print(f'Unique names: {len(set(names))}')

# Check specialization counts
for spec in ['Cardiology','Dentistry','Dermatology','Endocrinology','Gastroenterology','General Medicine','Gynecology','Neurology','Oncology','Ophthalmology','Orthopedics','Pediatrics','Psychiatry','Pulmonology','Urology']:
    count = c.count(f'>{spec}<')
    if count > 0:
        print(f'  {spec}: {count} cards')

# Test filters
r2 = urllib.request.urlopen('http://127.0.0.1:5000/doctors?specialization=Cardiology', timeout=3)
c2 = r2.read().decode()
print(f'\nCardiology filter: {c2.count("Cardiology")} mentions')

r3 = urllib.request.urlopen('http://127.0.0.1:5000/doctors?gender=Female', timeout=3)
c3 = r3.read().decode()
print(f'Female filter: {c3.count("Female")} mentions')

r4 = urllib.request.urlopen('http://127.0.0.1:5000/doctor/1', timeout=3)
c4 = r4.read().decode()
print(f'\nDoctor 1 details: {c4.count("Doctor")} mentions, INR: {chr(8377) in c4}')

print('\nAll tests passed!')
