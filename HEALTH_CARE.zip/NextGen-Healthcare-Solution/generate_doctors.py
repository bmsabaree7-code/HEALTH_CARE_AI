import sqlite3
import os
import hashlib
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'database.db')
DB_PATH = os.path.abspath(DB_PATH)

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Delete existing doctors and related data
conn = get_conn()
c = conn.cursor()
c.execute('DELETE FROM appointments')
c.execute('DELETE FROM prescriptions')
c.execute('DELETE FROM medical_records')
c.execute('DELETE FROM lab_reports')
c.execute('DELETE FROM notifications')
c.execute('DELETE FROM audit_logs')
c.execute('DELETE FROM telehealth')
c.execute('DELETE FROM doctors')
c.execute('DELETE FROM patients')
c.execute('DELETE FROM users WHERE role="doctor"')
conn.commit()

# ===== IMAGE MAPPING - Unique per doctor =====
# Male doctor images: various professional male doctor photos
# Female doctor images: various professional female doctor photos
male_images = [
    'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1583258292688-d0542b9b5c94?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1576820823815-8d0b1e0e0dcd?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1573497881129-cbf9e7a2b5d7?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1576670278388-9390bb352d85?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1559757170-65815450e125?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1519831524194-a7a1c4c12e05?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1581060939238-8e7e06125b8a?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1560750588-7097272d212d?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1609205491666-8d5d55d555d5?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08a?w=200&h=200&fit=crop',
]

female_images = [
    'https://images.unsplash.com/photo-1594824476967-48c8b9645c86?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1583394262757-5c5b1d8b1b3a?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1578745691778-e8f5d0b6c8b4?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1566450929425-1269f7f842e3?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1594366221612-4a7e0e1e5ac6?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1581060939238-8e7e06125b8a?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1581060939238-8e7e06125b8a?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1573497881129-cbf9e7a2b5d7?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1594366221612-4a7e0e1e5ac6?w=200&h=200&fit=crop',
]

# Use unique URLs per doctor by adding unique parameters
def get_male_image(idx):
    base = 'https://images.unsplash.com/photo-15'
    suffixes = [
        '559757148-5c350d0d3c56', '583258292688-d0542b9b5c94', '576820823815-8d0b1e0e0dcd',
        '516549655169-df83a0774514', '586528116311-ad8dd3c8310d', '573497881129-cbf9e7a2b5d7',
        '576670278388-9390bb352d85', '559757170-65815450e125', '519831524194-a7a1c4c12e05',
        '544367567-0f2fcb009e0b', '581060939238-8e7e06125b8a', '560750588-7097272d212d',
        '5609205491666-8d5d55d555d5', '5629909613654-28e377c37b09', '581091226825-a6a2a5aee158',
        '571771894821-ce9b6c11b08a', '583258292688-d0542b9b5c94', '576820823815-8d0b1e0e0dcd',
        '516549655169-df83a0774514', '586528116311-ad8dd3c8310d'
    ]
    s = suffixes[idx % len(suffixes)]
    return f'https://images.unsplash.com/photo-{s}?w=200&h=200&fit=crop'

def get_female_image(idx):
    base = 'https://images.unsplash.com/photo-15'
    suffixes = [
        '594824476967-48c8b9645c86', '559839734-2b71ea197ec2', '559757148-5c350d0d3c56',
        '583394262757-5c5b1d8b1b3a', '578745691778-e8f5d0b6c8b4', '559839734-2b71ea197ec2',
        '566450929425-1269f7f842e3', '594366221612-4a7e0e1e5ac6', '581091226825-a6a2a5aee158',
        '581060939238-8e7e06125b8a', '573497019940-1c28c88b4f3e', '586528116311-ad8dd3c8310d',
        '559839734-2b71ea197ec2', '581060939238-8e7e06125b8a', '573497881129-cbf9e7a2b5d7',
        '594366221612-4a7e0e1e5ac6', '559839734-2b71ea197ec2', '581060939238-8e7e06125b8a',
        '573497881129-cbf9e7a2b5d7', '594366221612-4a7e0e1e5ac6'
    ]
    s = suffixes[idx % len(suffixes)]
    return f'https://images.unsplash.com/photo-{s}?w=200&h=200&fit=crop'

# ===== COMPREHENSIVE DOCTOR DATA =====
# 10 doctors per specialization = 150 doctors
# Format: (name, email, mobile, dob, gender, address, specialization, qualification, experience, fee, about, rating, available_days, available_time, hospital, languages, expertise, bio, consultation_mode)

doctors = []

spec_data = {
    'Cardiology': {
        'qualifications': ['MBBS, MD Cardiology', 'MBBS, DNB Cardiology', 'MBBS, DM Cardiology', 'MBBS, MCh Cardiology'],
        'hospitals': ['AIIMS Heart Institute Delhi', 'Fortis Cardiac Centre Bangalore', 'Medanta Heart Institute Gurgaon', 'Apollo Hospitals Chennai', 'Max Heart Institute Delhi', 'Sri Venkateshwara Hospital Chennai', 'Lilavati Hospital Mumbai', 'Narayana Health Bangalore', 'Wockhardt Hospital Mumbai', 'Kokilaben Hospital Mumbai'],
        'expertise_list': ['Interventional cardiology', 'Heart attack treatment', 'Angioplasty', 'Heart failure management', 'Echocardiography', 'Preventive cardiology', 'Women heart health', 'Hypertension', 'Arrhythmia', 'Coronary artery disease'],
        'cities': ['Delhi', 'Bangalore', 'Gurgaon', 'Chennai', 'Mumbai', 'Pune', 'Hyderabad', 'Kolkata', 'Jaipur', 'Ahmedabad'],
        'modes': ['In-person', 'Telehealth']
    },
    'Dentistry': {
        'qualifications': ['BDS, MDS Conservative Dentistry', 'BDS, MDS Oral Surgery', 'BDS, MDS Orthodontics', 'BDS, MDS Periodontics'],
        'hospitals': ['BrightSmile Dental Clinic Mumbai', 'ImplantCare Dental Centre Mumbai', 'SmilePerfect Dental Delhi', 'DentalCare Hospital Pune', 'PerfectTeeth Clinic Chennai', 'OralHealth Centre Bangalore', 'ToothCare Hospital Kolkata', 'BrightDental Hyderabad', 'SmileHub Kochi', 'DentalPro Trivandrum'],
        'expertise_list': ['General dentistry', 'Cosmetic dentistry', 'Root canal treatment', 'Teeth whitening', 'Braces and alignment', 'Dental implants', 'Wisdom tooth extraction', 'Bone grafting', 'Periodontics', 'Prosthodontics'],
        'cities': ['Mumbai', 'Delhi', 'Pune', 'Chennai', 'Bangalore', 'Kolkata', 'Hyderabad', 'Kochi', 'Trivandrum', 'Jaipur'],
        'modes': ['In-person']
    },
    'Dermatology': {
        'qualifications': ['MBBS, MD Dermatology', 'MBBS, DNB Dermatology', 'MBBS, MD Venereology'],
        'hospitals': ['SkinCare Clinic Chennai', 'DermaCare Clinic Delhi', 'Dermatology Centre Bangalore', 'SkinHealth Hospital Mumbai', 'DermPerfect Pune', 'ClearSkin Clinic Hyderabad', 'GlowDerm Kolkata', 'SkinMed Chennai', 'DermaPlus Mumbai', 'Complexion Care Bangalore'],
        'expertise_list': ['Skin disorders', 'Hair loss treatment', 'Acne and eczema', 'Aesthetic dermatology', 'Laser treatments', 'Psoriasis', 'Skin cancer screening', 'Anti-aging treatments', 'Chemical peels', 'Microneedling'],
        'cities': ['Chennai', 'Delhi', 'Bangalore', 'Mumbai', 'Pune', 'Hyderabad', 'Kolkata', 'Chennai', 'Mumbai', 'Bangalore'],
        'modes': ['In-person', 'Telehealth']
    },
    'Endocrinology': {
        'qualifications': ['MBBS, MD Endocrinology', 'MBBS, DNB Endocrinology', 'MBBS, DM Endocrinology'],
        'hospitals': ['EndoCare Hospital Delhi', 'HormoneHealth Centre Delhi', 'ThyroidCare Clinic Mumbai', 'DiabetesCentre Bangalore', 'EndocrinePlus Kolkata', 'Hormona Hospital Chennai', 'CareEndo Pune', 'SugarCare Hyderabad', 'ThyroidPlus Kolkata', 'GlandCare Mumbai'],
        'expertise_list': ['Diabetes management', 'Thyroid disorders', 'Hormonal imbalances', 'Osteoporosis', 'PCOS', 'Metabolic syndrome', 'Hormone replacement therapy', 'Growth disorders', 'Adrenal disorders', 'Pituitary disorders'],
        'cities': ['Delhi', 'Delhi', 'Mumbai', 'Bangalore', 'Kolkata', 'Chennai', 'Pune', 'Hyderabad', 'Kolkata', 'Mumbai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Gastroenterology': {
        'qualifications': ['MBBS, MD Gastroenterology', 'MBBS, DNB Gastroenterology', 'MBBS, DM Gastroenterology'],
        'hospitals': ['GastroCare Hospital Mumbai', 'DigestiveCare Centre Mumbai', 'GIHealth Hospital Delhi', 'StomachCare Bangalore', 'DigestPlus Pune', 'GI Clinic Chennai', 'GastroPlus Kolkata', 'ColonCare Hyderabad', 'BowelHealth Mumbai', 'DigestiveZone Chennai'],
        'expertise_list': ['Liver diseases', 'IBS', 'Endoscopic procedures', 'Acid reflux', 'Colorectal health', 'Gastrointestinal cancer', 'Crohn disease', 'Ulcerative colitis', 'Celiac disease', 'Hepatitis'],
        'cities': ['Mumbai', 'Mumbai', 'Delhi', 'Bangalore', 'Pune', 'Chennai', 'Kolkata', 'Hyderabad', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'General Medicine': {
        'qualifications': ['MBBS, MD General Medicine', 'MBBS, DNB General Medicine', 'MBBS, MD Internal Medicine'],
        'hospitals': ['Bangalore General Hospital', 'Mumbai Family Care Clinic', 'CityMed Hospital Delhi', 'PrimeCare Hyderabad', 'MetroHealth Kolkata', 'WellnessPlus Chennai', 'GeneralCare Mumbai', 'FamilyMed Pune', 'CoreHealth Bangalore', 'VitalCare Mumbai'],
        'expertise_list': ['Preventive medicine', 'Diabetes management', 'Hypertension', 'Chronic disease management', 'Internal medicine', 'Family healthcare', 'Cardiovascular health', 'Respiratory health', 'Nutritional disorders', 'Geriatric medicine'],
        'cities': ['Bangalore', 'Mumbai', 'Delhi', 'Hyderabad', 'Kolkata', 'Chennai', 'Mumbai', 'Pune', 'Bangalore', 'Mumbai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Gynecology': {
        'qualifications': ['MBBS, MD Obstetrics & Gynecology', 'MBBS, DNB Gynecology', 'MBBS, MS Gynecology'],
        'hospitals': ['WomenCare Hospital Chennai', 'PCOS & Women Care Hospital Chennai', 'MaternityCare Mumbai', 'GynaePlus Bangalore', 'LadyCare Hospital Delhi', 'WomenHealth Kolkata', 'GynaecPlus Pune', 'MotherCare Hyderabad', 'FemiCare Mumbai', 'LadyWell Chennai'],
        'expertise_list': ['Prenatal care', 'Gynecologic surgery', 'PCOS', 'Fertility', 'Menopause management', 'Contraception', 'HPV and cervical cancer', 'Fibroids', 'Endometriosis', 'High-risk pregnancy'],
        'cities': ['Chennai', 'Chennai', 'Mumbai', 'Bangalore', 'Delhi', 'Kolkata', 'Pune', 'Hyderabad', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Neurology': {
        'qualifications': ['MBBS, MD, DM Neurology', 'MBBS, MD Neurology', 'MBBS, DNB Neurology'],
        'hospitals': ['NeuroCare Institute Kolkata', 'NeuroScience Centre Kolkata', 'BrainHealth Hospital Mumbai', 'NeuroPlus Delhi', 'MindBrain Bangalore', 'NeuroCare Chennai', 'BrainCentre Hyderabad', 'NerveHealth Pune', 'NeuroPath Mumbai', 'BrainCare Kolkata'],
        'expertise_list': ['Stroke care', 'Epilepsy', 'Movement disorders', 'Neuropathy', 'Migraine', 'Neuromodulation', 'Multiple sclerosis', 'Parkinson disease', 'Alzheimer disease', 'Brain tumors'],
        'cities': ['Kolkata', 'Kolkata', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune', 'Mumbai', 'Kolkata'],
        'modes': ['In-person', 'Telehealth']
    },
    'Oncology': {
        'qualifications': ['MBBS, MD Oncology', 'MBBS, DM Oncology', 'MBBS, DNB Oncology'],
        'hospitals': ['OncoCare Hospital Mumbai', 'Breast Cancer Centre Mumbai', 'CancerCare Delhi', 'TumorInstitute Bangalore', 'OncologyPlus Chennai', 'CancerCentre Kolkata', 'OncMax Hyderabad', 'CancerCare Pune', 'MahaCancer Mumbai', 'LifeCare Oncology Chennai'],
        'expertise_list': ['Medical oncology', 'Chemotherapy', 'Immunotherapy', 'Targeted therapy', 'Breast cancer', 'Gynecologic oncology', 'Lung cancer', 'Colorectal cancer', 'Prostate cancer', 'Skin cancer'],
        'cities': ['Mumbai', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Ophthalmology': {
        'qualifications': ['MBBS, MS Ophthalmology', 'MBBS, DNB Ophthalmology', 'MBBS, MD Ophthalmology'],
        'hospitals': ['EyeCare Vision Centre Bangalore', 'VisionPlus Eye Hospital Bangalore', 'EyeHealth Hospital Mumbai', 'OcuPlus Delhi', 'SightCare Chennai', 'VisionCentre Kolkata', 'EyePlus Pune', 'OptiCare Hyderabad', 'EyeVision Mumbai', 'ClearSight Chennai'],
        'expertise_list': ['Cataract surgery', 'LASIK', 'Retinal disorders', 'Glaucoma', 'Eye checkups', 'Corneal surgery', 'Pediatric eye care', 'Retinal surgery', 'Optometry', 'Dry eye syndrome'],
        'cities': ['Bangalore', 'Bangalore', 'Mumbai', 'Delhi', 'Chennai', 'Kolkata', 'Pune', 'Hyderabad', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Orthopedics': {
        'qualifications': ['MBBS, MS Orthopedics', 'MBBS, DNB Orthopedics', 'MBBS, MCh Orthopedics'],
        'hospitals': ['OrthoPlus Hospital Pune', 'OrthoCare Hospital Pune', 'JointCare Hospital Mumbai', 'BoneHealth Delhi', 'OrthoPlus Chennai', 'BoneMed Bangalore', 'OrthoPro Kolkata', 'JointPlus Hyderabad', 'BoneCare Mumbai', 'OrthoWell Pune'],
        'expertise_list': ['Joint replacement', 'Sports medicine', 'Arthroscopy', 'Spine surgery', 'Trauma', 'Pediatric orthopedics', 'Joint preservation', 'Shoulder surgery', 'Knee surgery', 'Hip surgery'],
        'cities': ['Pune', 'Pune', 'Mumbai', 'Delhi', 'Chennai', 'Bangalore', 'Kolkata', 'Hyderabad', 'Mumbai', 'Pune'],
        'modes': ['In-person', 'Telehealth']
    },
    'Pediatrics': {
        'qualifications': ['MBBS, MD Pediatrics', 'MBBS, DNB Pediatrics', 'MBBS, MD Neonatology'],
        'hospitals': ['KidCare Hospital Hyderabad', 'LittleStars Pediatric Centre Hyderabad', 'ChildrenCare Mumbai', 'BabyHealth Delhi', 'PedPlus Bangalore', 'KidZone Chennai', 'ChildFirst Kolkata', 'LittleMed Pune', 'BabyPlus Mumbai', 'KidCare Chennai'],
        'expertise_list': ['Neonatal care', 'Childhood asthma', 'Nutritional disorders', 'Vaccinations', 'Developmental disorders', 'Childhood infections', 'Pediatric emergencies', 'Adolescent medicine', 'Congenital disorders', 'Respiratory disorders'],
        'cities': ['Hyderabad', 'Hyderabad', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Pune', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Psychiatry': {
        'qualifications': ['MBBS, MD Psychiatry', 'MBBS, DNB Psychiatry', 'MBBS, MD Clinical Psychology'],
        'hospitals': ['MindCare Clinic Kolkata', 'Women MindCare Centre Kolkata', 'BrainMind Hospital Mumbai', 'PsychPlus Delhi', 'MentalHealth Bangalore', 'PsychCare Chennai', 'MindWell Kolkata', 'TherapyPlus Pune', 'PsychHub Mumbai', 'MindBridge Chennai'],
        'expertise_list': ['Anxiety disorders', 'Depression', 'CBT', 'Stress management', 'PTSD', 'Women mental health', 'Trauma recovery', 'Addiction', 'ADHD', 'Bipolar disorder'],
        'cities': ['Kolkata', 'Kolkata', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Pune', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Pulmonology': {
        'qualifications': ['MBBS, MD Pulmonology', 'MBBS, DNB Pulmonology', 'MBBS, DM Pulmonology'],
        'hospitals': ['LungCare Hospital Kolkata', 'LungHealth Clinic Kolkata', 'RespiratoryPlus Mumbai', 'BreathCare Delhi', 'PulmonaryBangalore', 'LungMed Chennai', 'AirwayCare Hyderabad', 'LungPro Pune', 'BreatheWell Mumbai', 'LungHealth Chennai'],
        'expertise_list': ['Respiratory diseases', 'Asthma management', 'COPD', 'TB treatment', 'ICU respiratory care', 'Interventional pulmonology', 'Sleep apnea', 'Allergic respiratory', 'Pulmonary fibrosis', 'Bronchoscopy'],
        'cities': ['Kolkata', 'Kolkata', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    },
    'Urology': {
        'qualifications': ['MBBS, MS, MCh Urology', 'MBBS, MS Urology', 'MBBS, DNB Urology'],
        'hospitals': ['UroCare Hospital Delhi', 'Women Urology Centre Delhi', 'UroPlus Mumbai', 'KidneyCare Bangalore', 'UroHealth Chennai', 'BladderPlus Kolkata', 'UroPro Hyderabad', 'RenalCare Pune', 'UroMed Mumbai', 'UroWell Chennai'],
        'expertise_list': ['Kidney stones', 'Prostate disorders', 'Robotic surgery', 'Bladder disorders', 'Female urology', 'Urinary incontinence', 'Minimally invasive procedures', 'UTIs', 'Erectile dysfunction', 'Renal transplant'],
        'cities': ['Delhi', 'Delhi', 'Mumbai', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Mumbai', 'Chennai'],
        'modes': ['In-person', 'Telehealth']
    }
}

first_names_male = ['Rahul', 'Arjun', 'Vikram', 'Deepak', 'Rajesh', 'Sanjay', 'Amit', 'Karan', 'Vikas', 'Rajeev',
    'Suresh', 'Mahesh', 'Gaurav', 'Rakesh', 'Mukesh', 'Dinesh', 'Ashok', 'Prakash', 'Manish', 'Santosh',
    'Pramod', 'Naresh', 'Raju', 'Kishan', 'Bhim', 'Yashpal', 'Sandeep', 'Pradeep', 'Bhavesh', 'Chetan',
    'Kunal', 'Nikhil', 'Rohit', 'Sumit', 'Akash', 'Vivek', 'Nitin', 'Ajay', 'Dharmesh', 'Hiren']

first_names_female = ['Priya', 'Sunita', 'Kavitha', 'Ananya', 'Meera', 'Swetha', 'Neha', 'Deepa', 'Anjali', 'Shweta',
    'Roshni', 'Pooja', 'Rina', 'Kavya', 'Nandini', 'Divya', 'Asha', 'Geeta', 'Seema', 'Reena',
    'Smti', 'Arti', 'Kirti', 'Manju', 'Savitri', 'Sudha', 'Bharti', 'Pushpa', 'Suresh', 'Alka',
    'Monika', 'Pallavi', 'Shikha', 'Tarla', 'Usha', 'Chhaya', 'Nisha', 'Pooja', 'Renu', 'Soniya']

last_names = ['Sharma', 'Patil', 'Mehra', 'Reddy', 'Gupta', 'Singh', 'Kumar', 'Das', 'Mishra', 'Iyer',
    'Nair', 'Pillai', 'Menon', 'Chaudhary', 'Bansal', 'Joshi', 'Agarwal', 'Malhotra', 'Deshmukh', 'Sinha',
    'Verma', 'Patel', 'Khanna', 'Oberoi', 'Bhatia', 'Trivedi', 'Seth', 'Rao', 'Thomas', 'Joseph',
    'Wilson', 'Fernandes', 'D’Souza', 'Pereira', 'Silva', 'Gonsalves', 'Lima', 'Costa', 'Martins', 'Ramos']

def generate_doctor_data():
    doctors = []
    doctor_idx = 0
    
    for spec_name, spec_info in spec_data.items():
        for i in range(10):
            gender = 'Male' if i % 2 == 0 else 'Female'
            idx = doctor_idx % 20
            
            if gender == 'Male':
                name = f'Dr. {first_names_male[i % len(first_names_male)]} {last_names[idx % len(last_names)]}'
                image = get_male_image(idx)
            else:
                name = f'Dr. {first_names_female[i % len(first_names_female)]} {last_names[idx % len(last_names)]}'
                image = get_female_image(idx)
            
            email = name.lower().replace(' ', '.').replace('.', '') + '@health.com'
            email = f'{name.split()[1].lower()}.{name.split()[0].lower()}@health.com'
            
            quals = spec_info['qualifications']
            hospitals = spec_info['hospitals']
            expertise = spec_info['expertise_list']
            cities = spec_info['cities']
            modes = spec_info['modes']
            
            qual = quals[i % len(quals)]
            hospital = hospitals[i % len(hospitals)]
            exp_list = [3, 5, 7, 8, 10, 12, 15, 18, 20, 22]
            fee_list = [249, 299, 349, 399, 449, 499]
            
            city = cities[i % len(cities)]
            
            doctor = (
                name,
                email,
                f'9876543{200 + len(doctors):03d}',
                f'{1960 + (i % 25):04d}-{((i % 12) + 1):02d}-{((i % 28) + 1):02d}',
                gender,
                f'{30 + i * 5} {["MG Road", "Park Street", "Residency Road", "Church Street", "Tank Road", "Cathedral Road"][i % 6]}, {city}',
                spec_name,
                qual,
                exp_list[i % len(exp_list)],
                fee_list[i % len(fee_list)],
                f'{spec_name} specialist with {exp_list[i % len(exp_list)]} years of clinical experience. Expert in {expertise[i % len(expertise)]}. Providing compassionate patient care at {hospital}.',
                4.5 + (i % 5) * 0.1,
                ['Mon-Fri', 'Mon-Wed-Fri', 'Tue-Thu-Sat', 'Mon-Tue-Thu', 'Mon-Wed-Sat'][i % 5],
                ['10:00 AM - 1:00 PM, 4:00 PM - 7:00 PM', '9:00 AM - 1:00 PM, 5:00 PM - 8:00 PM', '9:00 AM - 1:00 PM, 3:00 PM - 6:00 PM', '10:00 AM - 1:00 PM, 4:00 PM - 7:00 PM'][i % 4],
                hospital,
                ['Hindi, English', 'English', 'Tamil, English', 'Telugu, English', 'Bengali, English', 'Marathi, English', 'Kannada, English', 'Gujarati, English', 'Punjabi, English', 'Urdu, English'][i % 10],
                expertise[i % len(expertise)],
                f'{name.split()[-1]} is a dedicated {spec_name.lower()} specialist with {exp_list[i % len(exp_list)]} years of experience. Passionate about delivering exceptional healthcare outcomes through evidence-based medicine and compassionate patient-centered care at {hospital}.',
                modes[i % len(modes)]
            )
            doctors.append(doctor)
            doctor_idx += 1
    
    return doctors

# Generate all doctors
all_doctors = generate_doctor_data()
print(f'Total doctors generated: {len(all_doctors)}')

# Verify uniqueness
names = [d[0] for d in all_doctors]
print(f'Unique names: {len(set(names))}')
if len(set(names)) != len(names):
    print('WARNING: Duplicate names found!')

# Insert into database
for doctor in all_doctors:
    name, email, mobile, dob, gender, addr, spec_name, qual, exp, fee, about, rating, avail_days, avail_time, hospital, languages, expertise, bio, consult_mode = doctor
    
    c.execute('SELECT id FROM specializations WHERE name = ?', (spec_name,))
    spec = c.fetchone()
    spec_id = spec['id'] if spec else None
    
    hashed = hash_password('password123')
    c.execute('INSERT OR IGNORE INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
               (name, email, mobile, dob, gender, addr, hashed, 'doctor'))
    c.execute('SELECT id FROM users WHERE email = ?', (email,))
    user = c.fetchone()
    if user:
        c.execute('''INSERT OR IGNORE INTO doctors (user_id, specialization_id, qualification, experience, consultation_fee, about, rating, available_days, available_time, image, hospital, languages, expertise, gender, bio, consultation_mode)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (user['id'], spec_id, qual, exp, fee, about, rating, avail_days, avail_time, doctor[13], hospital, languages, expertise, gender, bio, consult_mode))

conn.commit()

# Verify
c.execute('SELECT COUNT(*) FROM doctors')
print(f'\nDoctors in database: {c.fetchone()[0]}')

c.execute('SELECT s.name, COUNT(d.id) FROM specializations s LEFT JOIN doctors d ON s.id = d.specialization_id GROUP BY s.name ORDER BY s.name')
print('\nDoctors per specialization:')
for r in c.fetchall():
    print(f'  {r[0]}: {r[1]}')

conn.close()
print('\nDatabase initialization complete!')
