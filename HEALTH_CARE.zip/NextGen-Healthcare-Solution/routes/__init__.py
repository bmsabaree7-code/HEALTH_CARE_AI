import os
import sqlite3
import hashlib
import uuid
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__, template_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'templates'), static_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'static'))
app.secret_key = 'nextgen-healthcare-secret-key-2024'
app.name = 'app'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, '..', 'database.db')
DB_PATH = os.path.abspath(DB_PATH)

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            if session.get('role') != role and session.get('role') != 'admin':
                flash('Unauthorized access.', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_current_user():
    if 'user_id' not in session:
        return None
    conn = get_conn()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    return user

def audit_log(action, description=""):
    if 'user_id' in session:
        try:
            conn = get_conn()
            conn.execute('INSERT INTO audit_logs (user_id, action, description) VALUES (?, ?, ?)',
                         (session['user_id'], action, description))
            conn.commit()
            conn.close()
        except:
            pass

@app.context_processor
def inject_user():
    user = None
    unread_data = None
    if 'user_id' in session:
        user = get_current_user()
        conn = get_conn()
        unread_data = conn.execute('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0', (session['user_id'],)).fetchone()
        patients_list = conn.execute('SELECT id, full_name FROM users WHERE role="patient" ORDER BY full_name').fetchall()
        conn.close()
    else:
        conn = get_conn()
        patients_list = conn.execute('SELECT id, full_name FROM users WHERE role="patient" ORDER BY full_name').fetchall()
        conn.close()
    return dict(current_user=user, patients_list=patients_list, unread=unread_data, doctor_photo=doctor_photo)

def _ensure_base():
    if not os.path.exists(DB_PATH):
        from database.init_db import init_db
        init_db()
    else:
        try:
            conn = get_conn()
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
            table_names = [t['name'] for t in tables]
            required = ['users', 'patients', 'doctors', 'specializations', 'appointments', 'medical_records', 'prescriptions', 'lab_reports', 'notifications', 'audit_logs', 'telehealth']
            for t in required:
                if t not in table_names:
                    conn.close()
                    from database.init_db import init_db
                    init_db()
                    return
            # Add rating column if missing
            doctor_cols = [row[1] for row in conn.execute("PRAGMA table_info(doctors)").fetchall()]
            if 'rating' not in doctor_cols:
                conn.execute("ALTER TABLE doctors ADD COLUMN rating REAL DEFAULT 4.5")
                conn.execute("ALTER TABLE doctors ADD COLUMN available_days TEXT DEFAULT 'Mon-Fri'")
                conn.commit()
            conn.close()
        except:
            from database.init_db import init_db
            init_db()

def ensure_db():
    _ensure_base()
    # always: schema fixes, doctor photos, demo patient records
    from database.helpers import migrate, seed_patient_records
    conn = get_conn()
    try:
        migrate(conn)
        seed_patient_records(conn)
    finally:
        conn.close()

ensure_db()

UPLOAD_URL = '/static/uploads/doctors'
UPLOAD_DIR = os.path.join(app.static_folder, 'uploads', 'doctors')
ALLOWED_PHOTO_EXT = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
MAX_PHOTO_BYTES = 3 * 1024 * 1024  # 3 MB
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024


PLACEHOLDER_PHOTO = '/static/images/doctors/placeholder.svg'


def default_portrait(gender, uid=None, conn=None):
    """Next unused white-coat doctor photo from static/images/doctors (empty string if the folder has none)."""
    from database.helpers import pick_photo
    if conn is not None:
        return pick_photo(conn, gender)
    c = get_conn()
    try:
        return pick_photo(c, gender)
    finally:
        c.close()


def save_doctor_photo(file_storage):
    """Validate + store an uploaded doctor photo.

    Returns the public URL (/static/uploads/doctors/<random>.<ext>) or None when no file
    was chosen. Raises ValueError with a user-friendly message for bad files.
    """
    if not file_storage or not getattr(file_storage, 'filename', ''):
        return None
    ext = os.path.splitext(file_storage.filename)[1].lower().lstrip('.')
    if ext not in ALLOWED_PHOTO_EXT:
        raise ValueError('Photo must be a PNG, JPG, WEBP or GIF image.')
    data = file_storage.read(MAX_PHOTO_BYTES + 1)
    if not data:
        return None
    if len(data) > MAX_PHOTO_BYTES:
        raise ValueError('Photo is too large (max 3 MB).')
    # check the real file signature, not only the extension
    sigs = (b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a')
    if not (data.startswith(sigs) or (data[:4] == b'RIFF' and data[8:12] == b'WEBP')):
        raise ValueError('That file is not a valid image.')
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    name = f"{uuid.uuid4().hex}.{'jpg' if ext == 'jpeg' else ext}"
    with open(os.path.join(UPLOAD_DIR, name), 'wb') as fh:
        fh.write(data)
    return f"{UPLOAD_URL}/{name}"


def delete_uploaded_photo(url):
    """Remove a previously uploaded photo (never touches remote portrait URLs)."""
    if url and url.startswith(UPLOAD_URL + '/'):
        path = os.path.join(UPLOAD_DIR, os.path.basename(url))
        try:
            os.remove(path)
        except OSError:
            pass


def doctor_photo(d):
    """Photo URL for a doctor: own upload, assigned pool photo or custom link; placeholder if there is none."""
    try:
        img = d['image']
    except Exception:
        img = ''
    img = img or ''
    if img.startswith(('http://', 'https://')):
        from database.helpers import is_stale_photo
        return PLACEHOLDER_PHOTO if is_stale_photo(img) else img
    if img.startswith('/static/') and os.path.exists(os.path.join(app.static_folder, img[len('/static/'):])):
        return img
    return PLACEHOLDER_PHOTO


from routes import main_routes

main = app

if __name__ == '__main__':
    app.run(debug=True, port=5000)
