import sqlite3
import os
from datetime import datetime
from flask import request, render_template, redirect, url_for, flash, session
import routes
from database.init_db import init_db

@routes.app.route('/')
def index():
    conn = routes.get_conn()
    doctors = conn.execute('''
        SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
        FROM doctors d
        JOIN users u ON d.user_id = u.id
        JOIN specializations s ON d.specialization_id = s.id
        WHERE u.role = 'doctor' AND d.availability = 'available'
        ORDER BY u.full_name
        LIMIT 6
    ''').fetchall()
    specializations = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    total_patients = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="patient"').fetchone()
    total_doctors = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="doctor"').fetchone()
    total_appointments = conn.execute('SELECT COUNT(*) as cnt FROM appointments').fetchone()
    conn.close()
    return render_template('index.html', doctors=doctors, specializations=specializations,
                          total_patients=total_patients, total_doctors=total_doctors,
                          total_appointments=total_appointments)

def _specializations():
    conn = routes.get_conn()
    rows = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    conn.close()
    return rows


def _insert_doctor_profile(conn, user_id, form, gender, photo_url, source):
    """Insert the doctors row for a new doctor account (photo falls back to a portrait photo)."""
    def num(key, default=0, cast=int):
        try:
            return max(cast(form.get(key) or default), 0)
        except (TypeError, ValueError):
            return default
    spec_id = form.get('specialization_id')
    qualification = form.get('qualification', '').strip()
    experience = num('experience')
    fee = num('consultation_fee', 0, float)
    hospital = form.get('hospital', '').strip()
    languages = form.get('languages', '').strip()
    about = form.get('about', '').strip()
    mode = form.get('consultation_mode', 'In-person')
    if mode not in ('In-person', 'Telehealth', 'Both'):
        mode = 'In-person'
    image = photo_url or routes.default_portrait(gender, user_id, conn)
    conn.execute('''INSERT INTO doctors (user_id, specialization_id, qualification, experience, consultation_fee,
                     about, bio, hospital, languages, gender, consultation_mode, image, availability, source)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', ?)''',
                 (user_id, spec_id, qualification, experience, fee, about, about, hospital, languages,
                  gender, mode, image, source))


@routes.app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = 'doctor' if request.form.get('role') == 'doctor' else 'patient'
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        mobile = request.form.get('mobile', '').strip()
        dob = request.form.get('date_of_birth', '').strip()
        gender = request.form.get('gender', '').strip()
        address = request.form.get('address', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        def back(msg):
            flash(msg, 'error')
            return render_template('register.html', specializations=_specializations(), form=request.form)

        if not all([full_name, email, mobile, dob, gender, address, password, confirm]):
            return back('All fields are required.')
        if password != confirm:
            return back('Passwords do not match.')
        if len(password) < 6:
            return back('Password must be at least 6 characters.')
        if role == 'doctor':
            if not request.form.get('specialization_id') or not request.form.get('qualification', '').strip():
                return back('Doctors must choose a specialization and enter a qualification.')
            if not full_name.lower().startswith('dr'):
                full_name = 'Dr. ' + full_name

        photo_url = None
        if role == 'doctor':
            try:
                photo_url = routes.save_doctor_photo(request.files.get('photo'))
            except ValueError as e:
                return back(str(e))

        conn = routes.get_conn()
        try:
            hashed = routes.hash_password(password)
            conn.execute('''INSERT INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                         (full_name, email, mobile, dob, gender, address, hashed, role))
            user_id = conn.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()['id']
            if role == 'doctor':
                _insert_doctor_profile(conn, user_id, request.form, gender, photo_url, 'registered')
            else:
                conn.execute('INSERT INTO patients (user_id) VALUES (?)', (user_id,))
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            routes.audit_log('registration', f'New {role} registered: {full_name}')
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.rollback()
            routes.delete_uploaded_photo(photo_url)
            conn.close()
            return back('Email already registered.')
        except Exception:
            conn.rollback()
            routes.delete_uploaded_photo(photo_url)
            conn.close()
            return back('An error occurred. Please try again.')
    return render_template('register.html', specializations=_specializations(), form={})

@routes.app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user_type = request.form.get('user_type', 'patient')

        if not email or not password:
            flash('Please enter email and password.', 'error')
            return render_template('login.html')

        conn = routes.get_conn()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()

        if user and user['password'] == routes.hash_password(password):
            session.clear()
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['full_name'] = user['full_name']
            flash(f'Welcome back, {user["full_name"]}!', 'success')
            routes.audit_log('login', f'User logged in: {session.get("full_name")}')
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user['role'] == 'doctor':
                return redirect(url_for('doctor_dashboard'))
            else:
                return redirect(url_for('patient_dashboard'))
        else:
            flash('Invalid email or password.', 'error')
    return render_template('login.html')

@routes.app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

@routes.app.route('/doctors')
def doctors_page():
    conn = routes.get_conn()
    query = request.args.get('q', '')
    spec_filter = request.args.get('specialization', '')
    gender_filter = request.args.get('gender', '')
    avail_filter = request.args.get('availability', '')
    exp_filter = request.args.get('experience', '')
    fee_range = request.args.get('fee_range', '')

    sql = '''SELECT d.*, u.full_name, u.email, u.mobile, u.created_at as registered_at, s.name as specialization_name, s.id as spec_id
              FROM doctors d
              JOIN users u ON d.user_id = u.id
              JOIN specializations s ON d.specialization_id = s.id
              WHERE u.role = 'doctor' '''
    params = []

    if query:
        sql += 'AND (u.full_name LIKE ? OR d.qualification LIKE ? OR s.name LIKE ?)'
        params.append(f'%{query}%')
        params.append(f'%{query}%')
        params.append(f'%{query}%')
    if spec_filter:
        sql += 'AND s.name = ? '
        params.append(spec_filter)
    if gender_filter:
        sql += 'AND d.gender = ? '
        params.append(gender_filter)
    if avail_filter:
        sql += 'AND d.availability = ? '
        params.append(avail_filter)
    if exp_filter:
        sql += 'AND d.experience >= ? '
        params.append(int(exp_filter))
    if fee_range:
        parts = fee_range.split('-')
        if len(parts) == 2:
            sql += 'AND d.consultation_fee >= ? AND d.consultation_fee <= ? '
            params.append(int(parts[0]))
            params.append(int(parts[1]))

    sql += 'ORDER BY u.full_name'
    doctors = conn.execute(sql, params).fetchall()
    specializations = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    conn.close()
    # doctors who signed up through the register form (or were added by admin) are listed
    # first with all their details, newest first
    filtering = any([query, spec_filter, gender_filter, avail_filter, exp_filter, fee_range])
    new_doctors = sorted([d for d in doctors if d['source'] == 'registered'], key=lambda d: d['id'], reverse=True)
    if not filtering:
        doctors = [d for d in doctors if d['source'] != 'registered']
    return render_template('doctors.html', doctors=doctors, new_doctors=new_doctors if not filtering else [],
                          specializations=specializations,
                          query=query, spec_filter=spec_filter, gender_filter=gender_filter,
                          avail_filter=avail_filter, exp_filter=exp_filter, fee_range=fee_range)

@routes.app.route('/doctor/<int:doctor_id>')
def doctor_details(doctor_id):
    conn = routes.get_conn()
    doctor = conn.execute('''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                              FROM doctors d
                              JOIN users u ON d.user_id = u.id
                              JOIN specializations s ON d.specialization_id = s.id
                              WHERE d.user_id = ?''', (doctor_id,)).fetchone()
    if doctor:
        avail_time = doctor['available_time'] or '10:00 AM - 1:00 PM, 4:00 PM - 7:00 PM'
        avail_slots = []
        for time_block in avail_time.split(','):
            time_block = time_block.strip()
            if '-' in time_block:
                start_str, end_str = time_block.split('-')
                start_str = start_str.strip()
                end_str = end_str.strip()
                try:
                    start_h, start_m = map(int, start_str.replace('AM','').replace('PM','').split(':'))
                    if 'PM' in start_str and start_h != 12:
                        start_h += 12
                    if 'AM' in start_str and start_h == 12:
                        start_h = 0
                    end_h, end_m = map(int, end_str.replace('AM','').replace('PM','').split(':'))
                    if 'PM' in end_str and end_h != 12:
                        end_h += 12
                    if 'AM' in end_str and end_h == 12:
                        end_h = 0
                    start_min = start_h * 60 + start_m
                    end_min = end_h * 60 + end_m
                    current = start_min
                    while current < end_min:
                        slot_h = current // 60
                        slot_m = current % 60
                        period = 'AM' if slot_h < 12 else 'PM'
                        display_h = slot_h % 12
                        if display_h == 0:
                            display_h = 12
                        slot_time = f'{display_h:02d}:{slot_m:02d} {period}'
                        avail_slots.append(slot_time)
                        current += 30
                except:
                    pass
        consultation_modes = ['In-person'] if doctor['consultation_mode'] == 'In-person' else ['In-person', 'Telehealth']
        if doctor['consultation_mode'] == 'Both' or not doctor['consultation_mode']:
            consultation_modes = ['In-person', 'Telehealth']
        conn.close()
        return render_template('doctor_details.html', doctor=doctor, avail_slots=avail_slots,
                               consultation_modes=consultation_modes)
    conn.close()
    flash('Doctor not found.', 'error')
    return redirect(url_for('doctors_page'))

@routes.app.route('/appointments', methods=['GET', 'POST'])
@routes.login_required
def appointments():
    conn = routes.get_conn()
    if session['role'] == 'patient':
        appointments = conn.execute('''SELECT a.*, u.full_name as doctor_name, s.name as specialization_name
                                       FROM appointments a
                                       JOIN users u ON a.doctor_id = u.id
                                       JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                                       WHERE a.patient_id = ? ORDER BY a.appointment_date DESC''',
                                    (session['user_id'],)).fetchall()
        conn.close()
        return render_template('appointments.html', appointments=appointments, role='patient')
    elif session['role'] == 'doctor':
        appts = conn.execute('''SELECT a.*, u.full_name as patient_name, a.id as appt_id
                                FROM appointments a
                                JOIN users u ON a.patient_id = u.id
                                WHERE a.doctor_id = ? ORDER BY a.appointment_date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('appointments.html', appointments=appts, role='doctor')
    conn.close()
    return redirect(url_for('index'))

@routes.app.route('/book_appointment', methods=['POST'])
@routes.login_required
def book_appointment():
    if session['role'] != 'patient':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))

    doctor_id = request.form.get('doctor_id')
    date = request.form.get('appointment_date')
    time = request.form.get('appointment_time')
    reason = request.form.get('reason', '').strip()
    consultation_mode = request.form.get('consultation_mode', 'In-person')

    if not doctor_id or not date or not time:
        flash('Please fill all required fields.', 'error')
        return redirect(url_for('doctor_details', doctor_id=doctor_id) if doctor_id else url_for('doctors_page'))

    if date < datetime.now().strftime('%Y-%m-%d'):
        flash('Please choose today or a future date.', 'error')
        return redirect(url_for('doctor_details', doctor_id=doctor_id))

    conn = routes.get_conn()
    try:
        doctor = conn.execute('SELECT user_id, qualification, specialization_id FROM doctors WHERE user_id = ?', (doctor_id,)).fetchone()
        if not doctor:
            flash('Doctor not found.', 'error')
            return redirect(url_for('index'))

        doctor_user_id = doctor['user_id']

        existing = conn.execute('''SELECT id FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ? AND status != 'cancelled' '''
                                , (doctor_user_id, date, time)).fetchall()
        if existing:
            flash('This time slot is already booked. Please choose another time.', 'error')
            return redirect(url_for('doctor_details', doctor_id=doctor_id))

        spec_name = conn.execute('SELECT name FROM specializations WHERE id = ?', (doctor['specialization_id'],)).fetchone()
        spec_name_val = spec_name['name'] if spec_name else 'General'

        cur = conn.execute('''INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status, consultation_mode)
                     VALUES (?, ?, ?, ?, ?, 'pending', ?)''',
                      (session['user_id'], doctor_user_id, date, time, reason, consultation_mode))
        appt_id = cur.lastrowid
        conn.commit()

        patient_name = session.get('full_name')
        notif = conn.execute('SELECT id FROM users WHERE role = "doctor" AND id = ?', (doctor_user_id,)).fetchone()
        if notif:
            conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                         (doctor_user_id, 'New Appointment', f'New appointment request from {patient_name} on {date} at {time} ({consultation_mode})'))
            conn.commit()

        doc_name = conn.execute('SELECT full_name FROM users WHERE id = ?', (doctor_user_id,)).fetchone()['full_name']
        # notification for the patient (shows in the bell + dashboard)
        conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                     (session['user_id'], 'Appointment Registered',
                      f'Your appointment #APT-{appt_id} with {doc_name} on {date} at {time} was registered successfully. Waiting for doctor confirmation.'))
        conn.commit()
        routes.audit_log('appointment_booked', f'Appointment booked for doctor_id={doctor_user_id}, mode={consultation_mode}')
        flash(f'Appointment successfully registered! #APT-{appt_id} with {doc_name} on {date} at {time}.', 'success')
        return redirect(url_for('appointment_confirmation', appt_id=appt_id))
    finally:
        conn.close()

@routes.app.route('/cancel_appointment/<int:appt_id>')
@routes.login_required
def cancel_appointment(appt_id):
    conn = routes.get_conn()
    try:
        if session['role'] == 'patient':
            appt = conn.execute('SELECT * FROM appointments WHERE id = ? AND patient_id = ?', (appt_id, session['user_id'])).fetchone()
            if appt:
                conn.execute('UPDATE appointments SET status = "cancelled" WHERE id = ?', (appt_id,))
                doctor = conn.execute('SELECT full_name FROM users WHERE id = ?', (appt['doctor_id'],)).fetchone()
                if doctor:
                    conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                                 (appt['doctor_id'], 'Appointment Cancelled', f'{session.get("full_name")} cancelled an appointment on {appt["appointment_date"]} at {appt["appointment_time"]}'))
                    conn.commit()
                flash('Appointment cancelled.', 'success')
                routes.audit_log('appointment_cancelled', f'Appointment {appt_id} cancelled')
            else:
                flash('Appointment not found.', 'error')
    finally:
        conn.close()
    return redirect(url_for('appointments'))

@routes.app.route('/accept_appointment/<int:appt_id>')
@routes.login_required
def accept_appointment(appt_id):
    if session['role'] == 'doctor':
        conn = routes.get_conn()
        try:
            appt = conn.execute('SELECT * FROM appointments WHERE id = ? AND doctor_id = ?', (appt_id, session['user_id'])).fetchone()
            if appt:
                conn.execute('UPDATE appointments SET status = "confirmed" WHERE id = ?', (appt_id,))
                conn.commit()
                patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (appt['patient_id'],)).fetchone()
                if patient:
                    conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                                 (appt['patient_id'], 'Appointment Confirmed', f'Your appointment with {session.get("full_name")} has been confirmed!'))
                    conn.commit()
                flash('Appointment accepted.', 'success')
            else:
                flash('Appointment not found.', 'error')
        finally:
            conn.close()
    return redirect(url_for('appointments'))

@routes.app.route('/reject_appointment/<int:appt_id>')
@routes.login_required
def reject_appointment(appt_id):
    if session['role'] == 'doctor':
        conn = routes.get_conn()
        try:
            appt = conn.execute('SELECT * FROM appointments WHERE id = ? AND doctor_id = ?', (appt_id, session['user_id'])).fetchone()
            if appt:
                conn.execute('UPDATE appointments SET status = "rejected" WHERE id = ?', (appt_id,))
                conn.commit()
                patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (appt['patient_id'],)).fetchone()
                if patient:
                    conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                                 (appt['patient_id'], 'Appointment Rejected', f'Sorry, your appointment with {session.get("full_name")} has been rejected.'))
                    conn.commit()
                flash('Appointment rejected.', 'success')
            else:
                flash('Appointment not found.', 'error')
        finally:
            conn.close()
    return redirect(url_for('appointments'))

@routes.app.route('/complete_appointment/<int:appt_id>')
@routes.login_required
def complete_appointment(appt_id):
    if session['role'] == 'doctor':
        conn = routes.get_conn()
        try:
            appt = conn.execute('SELECT * FROM appointments WHERE id = ? AND doctor_id = ?', (appt_id, session['user_id'])).fetchone()
            if appt:
                conn.execute('UPDATE appointments SET status = "completed" WHERE id = ?', (appt_id,))
                conn.commit()
                patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (appt['patient_id'],)).fetchone()
                if patient:
                    conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                                 (appt['patient_id'], 'Appointment Completed', f'Your appointment with {session.get("full_name")} is now completed.'))
                    conn.commit()
                flash('Appointment marked as completed.', 'success')
            else:
                flash('Appointment not found.', 'error')
        finally:
            conn.close()
    return redirect(url_for('appointments'))

@routes.app.route('/patient_dashboard')
@routes.login_required
def patient_dashboard():
    if session['role'] != 'patient':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    user = routes.get_current_user()
    patient = conn.execute('SELECT * FROM patients WHERE user_id = ?', (session['user_id'],)).fetchone()
    upcoming = conn.execute('''SELECT a.*, u.full_name as doctor_name, s.name as specialization_name
                               FROM appointments a
                               JOIN users u ON a.doctor_id = u.id
                               JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                               WHERE a.patient_id = ? AND a.status != 'cancelled' ORDER BY a.appointment_date LIMIT 1''',
                             (session['user_id'],)).fetchone()
    total_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE patient_id = ?', (session['user_id'],)).fetchone()
    records_count = conn.execute('SELECT COUNT(*) as cnt FROM medical_records WHERE patient_id = ?', (session['user_id'],)).fetchone()
    presc_count = conn.execute('SELECT COUNT(*) as cnt FROM prescriptions WHERE patient_id = ?', (session['user_id'],)).fetchone()
    unread = conn.execute('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0', (session['user_id'],)).fetchone()
    notifications = conn.execute('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5', (session['user_id'],)).fetchall()
    lab_reports = conn.execute('''SELECT lr.*, u.full_name as doctor_name FROM lab_reports lr
                                  JOIN users u ON lr.doctor_id = u.id WHERE patient_id = ? ORDER BY lr.test_date DESC LIMIT 5''',
                               (session['user_id'],)).fetchall()
    conn.close()
    return render_template('patient_dashboard.html', user=user, patient=patient, upcoming=upcoming,
                          total_appts=total_appts, records_count=records_count, presc_count=presc_count,
                          unread=unread, notifications=notifications, lab_reports=lab_reports)

@routes.app.route('/doctor_dashboard')
@routes.login_required
def doctor_dashboard():
    if session['role'] != 'doctor':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    user = routes.get_current_user()
    doctor = conn.execute('SELECT d.*, u.full_name, s.name as specialization_name FROM doctors d JOIN users u ON u.id = d.user_id JOIN specializations s ON d.specialization_id = s.id WHERE d.user_id = ?', (session['user_id'],)).fetchone()
    today = datetime.now().strftime('%Y-%m-%d')
    today_appts = conn.execute('''SELECT a.*, u.full_name as patient_name, a.id as appt_id
                                  FROM appointments a JOIN users u ON a.patient_id = u.id
                                  WHERE a.doctor_id = ? AND a.appointment_date = ? ORDER BY a.appointment_time''',
                             (session['user_id'], today)).fetchall()
    pending_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE doctor_id = ? AND status = "pending"', (session['user_id'],)).fetchone()
    completed_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE doctor_id = ? AND status = "completed"', (session['user_id'],)).fetchone()
    total_patients = conn.execute('SELECT COUNT(DISTINCT patient_id) as cnt FROM appointments WHERE doctor_id = ?', (session['user_id'],)).fetchone()
    unread = conn.execute('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0', (session['user_id'],)).fetchone()
    notifications = conn.execute('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5', (session['user_id'],)).fetchall()
    conn.close()
    return render_template('doctor_dashboard.html', user=user, doctor=doctor, today_appts=today_appts,
                          pending_appts=pending_appts, completed_appts=completed_appts,
                          total_patients=total_patients, unread=unread, notifications=notifications)

@routes.app.route('/admin_dashboard')
@routes.login_required
@routes.role_required('admin')
def admin_dashboard():
    conn = routes.get_conn()
    total_patients = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="patient"').fetchone()
    total_doctors = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="doctor"').fetchone()
    total_appointments = conn.execute('SELECT COUNT(*) as cnt FROM appointments').fetchone()
    pending_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="pending"').fetchone()
    confirmed_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="confirmed"').fetchone()
    completed_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="completed"').fetchone()
    total_records = conn.execute('SELECT COUNT(*) as cnt FROM medical_records').fetchone()
    recent_patients = conn.execute('SELECT u.*, p.blood_group FROM users u JOIN patients p ON u.id = p.user_id WHERE u.role="patient" ORDER BY u.created_at DESC LIMIT 5').fetchall()
    recent_appointments = conn.execute('''SELECT a.*, u.full_name as patient_name, d_u.full_name as doctor_name
                                         FROM appointments a JOIN users u ON a.patient_id = u.id
                                         JOIN users d_u ON a.doctor_id = d_u.id
                                         ORDER BY a.created_at DESC LIMIT 5''').fetchall()
    notifications = conn.execute('SELECT * FROM notifications ORDER BY id DESC LIMIT 5').fetchall()
    conn.close()
    return render_template('admin_dashboard.html', total_patients=total_patients, total_doctors=total_doctors,
                          total_appointments=total_appointments, pending_appts=pending_appts,
                          confirmed_appts=confirmed_appts, completed_appts=completed_appts,
                          total_records=total_records, recent_patients=recent_patients,
                          recent_appointments=recent_appointments)

@routes.app.route('/patients')
@routes.login_required
@routes.role_required('admin')
def admin_patients():
    conn = routes.get_conn()
    search = request.args.get('q', '')
    if search:
        patients = conn.execute('''SELECT u.*, p.blood_group FROM users u JOIN patients p ON u.id = p.user_id
                                   WHERE u.role="patient" AND (u.full_name LIKE ? OR u.email LIKE ? OR u.mobile LIKE ?)''',
                                (f'%{search}%', f'%{search}%', f'%{search}%')).fetchall()
    else:
        patients = conn.execute('''SELECT u.*, p.blood_group FROM users u JOIN patients p ON u.id = p.user_id
                                   WHERE u.role="patient" ORDER BY u.full_name''').fetchall()
    conn.close()
    return render_template('admin_patients.html', patients=patients, search=search)

@routes.app.route('/doctors_mgmt')
@routes.login_required
@routes.role_required('admin')
def admin_doctors():
    conn = routes.get_conn()
    search = request.args.get('q', '')
    if search:
        doctors = conn.execute('''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                                   FROM doctors d JOIN users u ON d.user_id = u.id
                                   JOIN specializations s ON d.specialization_id = s.id
                                   WHERE u.full_name LIKE ? OR u.email LIKE ? OR s.name LIKE ?''',
                                (f'%{search}%', f'%{search}%', f'%{search}%')).fetchall()
    else:
        doctors = conn.execute('''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                                   FROM doctors d JOIN users u ON d.user_id = u.id
                                   JOIN specializations s ON d.specialization_id = s.id
                                   ORDER BY (d.source = 'registered') DESC, CASE WHEN d.source = 'registered' THEN d.id END DESC, u.full_name''').fetchall()
    specializations = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    conn.close()
    return render_template('admin_doctors.html', doctors=doctors, specializations=specializations, search=search)

@routes.app.route('/add_specialization', methods=['POST'])
@routes.login_required
@routes.role_required('admin')
def add_specialization():
    name = request.form.get('name', '').strip()
    if name:
        conn = routes.get_conn()
        try:
            conn.execute('INSERT INTO specializations (name) VALUES (?)', (name,))
            conn.commit()
            flash('Specialization added.', 'success')
        except sqlite3.IntegrityError:
            flash('Specialization already exists.', 'error')
        conn.close()
    return redirect(url_for('admin_doctors'))

@routes.app.route('/delete_specialization/<int:spec_id>')
@routes.login_required
@routes.role_required('admin')
def delete_specialization(spec_id):
    conn = routes.get_conn()
    conn.execute('DELETE FROM specializations WHERE id = ?', (spec_id,))
    conn.commit()
    conn.close()
    flash('Specialization deleted.', 'success')
    return redirect(url_for('admin_doctors'))

@routes.app.route('/add_doctor', methods=['GET', 'POST'])
@routes.login_required
@routes.role_required('admin')
def add_doctor():
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        mobile = request.form.get('mobile', '').strip()
        dob = request.form.get('date_of_birth', '').strip()
        gender = request.form.get('gender', '').strip()
        address = request.form.get('address', '').strip()
        password = request.form.get('password', '')
        specialization_id = request.form.get('specialization_id')

        if not all([full_name, email, mobile, dob, gender, address, password, specialization_id]):
            flash('All required fields must be filled.', 'error')
            return redirect(url_for('admin_doctors'))

        try:
            photo_url = routes.save_doctor_photo(request.files.get('photo'))
        except ValueError as e:
            flash(str(e), 'error')
            return redirect(url_for('admin_doctors'))

        conn = routes.get_conn()
        try:
            hashed = routes.hash_password(password)
            conn.execute('''INSERT INTO users (full_name, email, mobile, date_of_birth, gender, address, password, role)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 'doctor')''',
                         (full_name, email, mobile, dob, gender, address, hashed))
            user_id = conn.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone()['id']
            _insert_doctor_profile(conn, user_id, request.form, gender, photo_url, 'registered')
            conn.commit()
            flash('Doctor added successfully.', 'success')
        except sqlite3.IntegrityError:
            conn.rollback()
            routes.delete_uploaded_photo(photo_url)
            flash('Email already registered.', 'error')
        conn.close()
        return redirect(url_for('admin_doctors'))

    # GET: render the admin doctors page with add form
    return redirect(url_for('admin_doctors'))

@routes.app.route('/delete_doctor/<int:user_id>')
@routes.login_required
@routes.role_required('admin')
def delete_doctor(user_id):
    conn = routes.get_conn()
    row = conn.execute('SELECT image FROM doctors WHERE user_id = ?', (user_id,)).fetchone()
    if row:
        routes.delete_uploaded_photo(row['image'])
    conn.execute('DELETE FROM doctors WHERE user_id = ?', (user_id,))
    conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    flash('Doctor deleted.', 'success')
    return redirect(url_for('admin_doctors'))

@routes.app.route('/admin_records')
@routes.login_required
@routes.role_required('admin')
def admin_records():
    conn = routes.get_conn()
    records = conn.execute('''SELECT mr.*, u.full_name as patient_name, d_u.full_name as doctor_name
                              FROM medical_records mr JOIN users u ON mr.patient_id = u.id
                              JOIN users d_u ON mr.doctor_id = d_u.id ORDER BY mr.created_at DESC''').fetchall()
    conn.close()
    return render_template('admin_records.html', records=records)

@routes.app.route('/admin_prescriptions')
@routes.login_required
@routes.role_required('admin')
def admin_prescriptions():
    conn = routes.get_conn()
    prescs = conn.execute('''SELECT p.*, u.full_name as patient_name, d_u.full_name as doctor_name
                             FROM prescriptions p JOIN users u ON p.patient_id = u.id
                             JOIN users d_u ON p.doctor_id = d_u.id ORDER BY p.date DESC''').fetchall()
    conn.close()
    return render_template('admin_prescriptions.html', prescriptions=prescs)

@routes.app.route('/admin_lab_reports')
@routes.login_required
@routes.role_required('admin')
def admin_lab_reports():
    conn = routes.get_conn()
    reports = conn.execute('''SELECT lr.*, u.full_name as patient_name, d_u.full_name as doctor_name
                              FROM lab_reports lr JOIN users u ON lr.patient_id = u.id
                              JOIN users d_u ON lr.doctor_id = d_u.id ORDER BY lr.test_date DESC''').fetchall()
    conn.close()
    return render_template('admin_lab_reports.html', lab_reports=reports)

def _next_url(patient_id=None):
    nxt = request.form.get('next', '')
    if nxt.startswith('/') and not nxt.startswith('//'):
        return nxt
    if patient_id:
        try:
            return url_for('patient_record', patient_id=int(patient_id))
        except (TypeError, ValueError):
            pass
    return url_for('appointments')

def _can_view_patient(conn, patient_id):
    role = session.get('role')
    if role == 'admin':
        return True
    if role == 'patient':
        return session['user_id'] == patient_id
    if role == 'doctor':
        uid = session['user_id']
        for sql in ('SELECT 1 FROM appointments WHERE doctor_id=? AND patient_id=?',
                    'SELECT 1 FROM medical_records WHERE doctor_id=? AND patient_id=?',
                    'SELECT 1 FROM prescriptions WHERE doctor_id=? AND patient_id=?',
                    'SELECT 1 FROM lab_reports WHERE doctor_id=? AND patient_id=?'):
            if conn.execute(sql, (uid, patient_id)).fetchone():
                return True
    return False

@routes.app.route('/my_patients')
@routes.login_required
def my_patients():
    if session['role'] not in ('doctor', 'admin'):
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    q = request.args.get('q', '').strip()
    if session['role'] == 'admin':
        base = '''SELECT u.id, u.full_name, u.email, u.mobile, u.gender, u.date_of_birth, p.blood_group, p.allergies
                    FROM users u LEFT JOIN patients p ON p.user_id = u.id WHERE u.role = 'patient' '''
        params = []
    else:
        base = '''SELECT u.id, u.full_name, u.email, u.mobile, u.gender, u.date_of_birth, p.blood_group, p.allergies
                    FROM users u LEFT JOIN patients p ON p.user_id = u.id
                    WHERE u.role = 'patient' AND (
                        u.id IN (SELECT patient_id FROM appointments WHERE doctor_id = ?) OR
                        u.id IN (SELECT patient_id FROM medical_records WHERE doctor_id = ?) OR
                        u.id IN (SELECT patient_id FROM prescriptions WHERE doctor_id = ?) OR
                        u.id IN (SELECT patient_id FROM lab_reports WHERE doctor_id = ?)) '''
        params = [session['user_id']] * 4
    if q:
        base += ' AND (u.full_name LIKE ? OR u.email LIKE ? OR u.mobile LIKE ?)'
        params += [f'%{q}%'] * 3
    base += ' ORDER BY u.full_name'
    patients = []
    for r in conn.execute(base, params).fetchall():
        d = dict(r)
        d['records'] = conn.execute('SELECT COUNT(*) FROM medical_records WHERE patient_id=?', (r['id'],)).fetchone()[0]
        d['rx'] = conn.execute('SELECT COUNT(*) FROM prescriptions WHERE patient_id=?', (r['id'],)).fetchone()[0]
        d['labs'] = conn.execute('SELECT COUNT(*) FROM lab_reports WHERE patient_id=?', (r['id'],)).fetchone()[0]
        last = conn.execute('SELECT MAX(appointment_date) FROM appointments WHERE patient_id=?', (r['id'],)).fetchone()[0]
        d['last_visit'] = last or 'N/A'
        patients.append(d)
    conn.close()
    return render_template('my_patients.html', patients=patients, q=q)

@routes.app.route('/patient/<int:patient_id>')
@routes.login_required
def patient_record(patient_id):
    conn = routes.get_conn()
    try:
        if not _can_view_patient(conn, patient_id):
            flash('You do not have access to this patient record.', 'error')
            return redirect(url_for('index'))
        patient = conn.execute('''SELECT u.*, p.blood_group, p.allergies, p.emergency_contact
                                  FROM users u LEFT JOIN patients p ON p.user_id = u.id
                                  WHERE u.id = ? AND u.role = 'patient' ''', (patient_id,)).fetchone()
        if not patient:
            flash('Patient not found.', 'error')
            return redirect(url_for('index'))
        records = conn.execute('''SELECT mr.*, u.full_name AS doctor_name FROM medical_records mr
                                  JOIN users u ON u.id = mr.doctor_id WHERE mr.patient_id = ? ORDER BY mr.visit_date DESC''', (patient_id,)).fetchall()
        prescs = conn.execute('''SELECT p.*, u.full_name AS doctor_name FROM prescriptions p
                                 JOIN users u ON u.id = p.doctor_id WHERE p.patient_id = ? ORDER BY p.date DESC''', (patient_id,)).fetchall()
        labs = conn.execute('''SELECT lr.*, u.full_name AS doctor_name FROM lab_reports lr
                              JOIN users u ON u.id = lr.doctor_id WHERE lr.patient_id = ? ORDER BY lr.test_date DESC''', (patient_id,)).fetchall()
        appts = conn.execute('''SELECT a.*, u.full_name AS doctor_name FROM appointments a
                               JOIN users u ON u.id = a.doctor_id WHERE a.patient_id = ? ORDER BY a.appointment_date DESC''', (patient_id,)).fetchall()
        routes.audit_log('patient_record_viewed', f'Viewed record of patient_id={patient_id}')
        return render_template('patient_record.html', patient=patient, records=records, prescriptions=prescs,
                               lab_reports=labs, appts=appts, today=datetime.now().strftime('%Y-%m-%d'))
    finally:
        conn.close()

@routes.app.route('/medical_records')
@routes.login_required
def medical_records():
    if session['role'] == 'patient':
        conn = routes.get_conn()
        records = conn.execute('''SELECT mr.*, u.full_name as doctor_name FROM medical_records mr
                                  JOIN users u ON mr.doctor_id = u.id WHERE patient_id = ? ORDER BY mr.visit_date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('medical_records.html', records=records, role='patient')
    elif session['role'] == 'doctor':
        conn = routes.get_conn()
        records = conn.execute('''SELECT mr.*, u.full_name as patient_name FROM medical_records mr
                                  JOIN users u ON mr.patient_id = u.id WHERE doctor_id = ? ORDER BY mr.visit_date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('medical_records.html', records=records, role='doctor')
    return redirect(url_for('index'))

@routes.app.route('/add_medical_record', methods=['POST'])
@routes.login_required
def add_medical_record():
    if session['role'] != 'doctor':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))

    patient_id = request.form.get('patient_id')
    visit_date = request.form.get('visit_date')
    diagnosis = request.form.get('diagnosis', '').strip()
    symptoms = request.form.get('symptoms', '').strip()
    treatment = request.form.get('treatment', '').strip()
    notes = request.form.get('notes', '').strip()

    if not patient_id or not visit_date:
        flash('Please fill all required fields.', 'error')
        return redirect(_next_url(patient_id))

    conn = routes.get_conn()
    try:
        conn.execute('''INSERT INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, symptoms, treatment, notes)
                     VALUES (?, ?, ?, ?, ?, ?, ?)''',
                     (patient_id, session['user_id'], visit_date, diagnosis, symptoms, treatment, notes))
        conn.commit()
        patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (patient_id,)).fetchone()
        if patient:
            conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                         (patient_id, 'Medical Record Added', f'A new medical record has been added by {session.get("full_name")}. Diagnosis: {diagnosis}'))
            conn.commit()
        flash('Medical record added.', 'success')
        routes.audit_log('medical_record_added', f'Medical record added for patient_id={patient_id}')
    finally:
        conn.close()
    return redirect(_next_url(patient_id))

@routes.app.route('/prescriptions')
@routes.login_required
def prescriptions():
    if session['role'] == 'patient':
        conn = routes.get_conn()
        prescs = conn.execute('''SELECT p.*, u.full_name as doctor_name FROM prescriptions p
                                  JOIN users u ON p.doctor_id = u.id WHERE patient_id = ? ORDER BY p.date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('prescriptions.html', prescriptions=prescs, role='patient')
    elif session['role'] == 'doctor':
        conn = routes.get_conn()
        prescs = conn.execute('''SELECT p.*, u.full_name as patient_name FROM prescriptions p
                                  JOIN users u ON p.patient_id = u.id WHERE doctor_id = ? ORDER BY p.date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('prescriptions.html', prescriptions=prescs, role='doctor')
    return redirect(url_for('index'))

@routes.app.route('/add_prescription', methods=['POST'])
@routes.login_required
def add_prescription():
    if session['role'] != 'doctor':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))

    patient_id = request.form.get('patient_id')
    medicine_name = request.form.get('medicine_name', '').strip()
    dosage = request.form.get('dosage', '').strip()
    frequency = request.form.get('frequency', '').strip()
    duration = request.form.get('duration', '').strip()
    instructions = request.form.get('instructions', '').strip()
    date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))

    if not patient_id or not medicine_name:
        flash('Please fill all required fields.', 'error')
        return redirect(_next_url(patient_id))

    conn = routes.get_conn()
    try:
        conn.execute('''INSERT INTO prescriptions (patient_id, doctor_id, medicine_name, dosage, frequency, duration, instructions, date)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                     (patient_id, session['user_id'], medicine_name, dosage, frequency, duration, instructions, date))
        conn.commit()
        patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (patient_id,)).fetchone()
        if patient:
            conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                         (patient_id, 'Prescription Added', f'A new prescription for {medicine_name} has been added by {session.get("full_name")}. Dosage: {dosage}, Frequency: {frequency}'))
            conn.commit()
        flash('Prescription added.', 'success')
        routes.audit_log('prescription_added', f'Prescription for {medicine_name} added')
    finally:
        conn.close()
    return redirect(_next_url(patient_id))

@routes.app.route('/add_prescription_to_patient', methods=['POST'])
@routes.login_required
def add_prescription_to_patient():
    return redirect(url_for('prescriptions'))

@routes.app.route('/lab_reports')
@routes.login_required
def lab_reports():
    if session['role'] == 'patient':
        conn = routes.get_conn()
        reports = conn.execute('''SELECT lr.*, u.full_name as doctor_name FROM lab_reports lr
                                  JOIN users u ON lr.doctor_id = u.id WHERE patient_id = ? ORDER BY lr.test_date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('lab_reports.html', reports=reports, role='patient')
    elif session['role'] == 'doctor':
        conn = routes.get_conn()
        reports = conn.execute('''SELECT lr.*, u.full_name as patient_name FROM lab_reports lr
                                  JOIN users u ON lr.patient_id = u.id WHERE doctor_id = ? ORDER BY lr.test_date DESC''',
                             (session['user_id'],)).fetchall()
        conn.close()
        return render_template('lab_reports.html', reports=reports, role='doctor')
    return redirect(url_for('index'))

@routes.app.route('/add_lab_report', methods=['POST'])
@routes.login_required
def add_lab_report():
    if session['role'] != 'doctor':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))

    test_name = request.form.get('test_name', '').strip()
    patient_id = request.form.get('patient_id')
    test_date = request.form.get('test_date')
    result = request.form.get('result', '').strip()
    reference_range = request.form.get('reference_range', '').strip()
    status = request.form.get('status', 'pending')
    remarks = request.form.get('remarks', '').strip()

    if not test_name or not patient_id:
        flash('Please fill all required fields.', 'error')
        return redirect(_next_url(patient_id))

    conn = routes.get_conn()
    try:
        conn.execute('''INSERT INTO lab_reports (test_name, patient_id, doctor_id, test_date, result, reference_range, status, remarks)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                     (test_name, patient_id, session['user_id'], test_date, result, reference_range, status, remarks))
        conn.commit()
        patient = conn.execute('SELECT full_name FROM users WHERE id = ?', (patient_id,)).fetchone()
        if patient:
            conn.execute('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                         (patient_id, 'Lab Report Available', f'A new lab report for {test_name} is available. Status: {status}'))
            conn.commit()
        flash('Lab report added.', 'success')
        routes.audit_log('lab_report_added', f'Lab report {test_name} added')
    finally:
        conn.close()
    return redirect(_next_url(patient_id))

@routes.app.route('/profile')
@routes.login_required
def profile():
    conn = routes.get_conn()
    user = routes.get_current_user()
    if session['role'] == 'patient':
        patient = conn.execute('SELECT * FROM patients WHERE user_id = ?', (session['user_id'],)).fetchone()
        conn.close()
        return render_template('profile.html', user=user, patient=patient, role='patient')
    elif session['role'] == 'doctor':
        doctor = conn.execute('SELECT d.*, s.name as specialization_name FROM doctors d JOIN specializations s ON d.specialization_id = s.id WHERE d.user_id = ?', (session['user_id'],)).fetchone()
        conn.close()
        return render_template('profile.html', user=user, doctor=doctor, role='doctor')
    conn.close()
    return render_template('profile.html', user=user, role='admin')

@routes.app.route('/update_profile', methods=['POST'])
@routes.login_required
def update_profile():
    full_name = request.form.get('full_name', '').strip()
    mobile = request.form.get('mobile', '').strip()
    address = request.form.get('address', '').strip()

    if not full_name or not mobile or not address:
        flash('All fields are required.', 'error')
        return redirect(url_for('profile'))

    conn = routes.get_conn()
    conn.execute('UPDATE users SET full_name = ?, mobile = ?, address = ? WHERE id = ?',
                 (full_name, mobile, address, session['user_id']))
    conn.commit()

    if session['role'] == 'patient':
        blood_group = request.form.get('blood_group', '')
        allergies = request.form.get('allergies', '')
        emergency_contact = request.form.get('emergency_contact', '')
        conn.execute('UPDATE patients SET blood_group = ?, allergies = ?, emergency_contact = ? WHERE user_id = ?',
                     (blood_group, allergies, emergency_contact, session['user_id']))
        conn.commit()
    elif session['role'] == 'doctor':
        qualification = request.form.get('qualification', '')
        experience = request.form.get('experience', 0)
        consultation_fee = request.form.get('consultation_fee', 0)
        about = request.form.get('about', '')
        conn.execute('UPDATE doctors SET qualification = ?, experience = ?, consultation_fee = ?, about = ? WHERE user_id = ?',
                     (qualification, experience, consultation_fee, about, session['user_id']))
        conn.commit()
        # photo: upload a new one, or remove it to go back to a default portrait photo
        row = conn.execute('SELECT image, gender FROM doctors WHERE user_id = ?', (session['user_id'],)).fetchone()
        if row:
            try:
                new_photo = routes.save_doctor_photo(request.files.get('photo'))
            except ValueError as e:
                new_photo = None
                flash(str(e), 'error')
            if new_photo:
                routes.delete_uploaded_photo(row['image'])
                conn.execute('UPDATE doctors SET image = ? WHERE user_id = ?', (new_photo, session['user_id']))
                conn.commit()
            elif request.form.get('remove_photo'):
                routes.delete_uploaded_photo(row['image'])
                conn.execute('UPDATE doctors SET image = ? WHERE user_id = ?',
                             (routes.default_portrait(row['gender'], session['user_id'], conn), session['user_id']))
                conn.commit()

    conn.close()
    flash('Profile updated successfully.', 'success')
    return redirect(url_for('profile'))

@routes.app.route('/notifications')
@routes.login_required
def notifications_page():
    conn = routes.get_conn()
    notifs = conn.execute('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC', (session['user_id'],)).fetchall()
    conn.close()
    return render_template('notifications.html', notifications=notifs)

@routes.app.route('/mark_notification_read/<int:notif_id>')
@routes.login_required
def mark_notification_read(notif_id):
    conn = routes.get_conn()
    conn.execute('UPDATE notifications SET is_read = 1 WHERE id = ?', (notif_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('notifications_page'))

@routes.app.route('/health_report')
@routes.login_required
def health_report():
    if session['role'] != 'patient':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    records = conn.execute('''SELECT mr.*, u.full_name as doctor_name FROM medical_records mr
                              JOIN users u ON mr.doctor_id = u.id WHERE patient_id = ? ORDER BY mr.visit_date DESC''',
                           (session['user_id'],)).fetchall()
    prescs = conn.execute('''SELECT p.*, u.full_name as doctor_name FROM prescriptions p
                              JOIN users u ON p.doctor_id = u.id WHERE patient_id = ? ORDER BY p.date DESC''',
                          (session['user_id'],)).fetchall()
    lab_reports = conn.execute('''SELECT lr.*, u.full_name as doctor_name FROM lab_reports lr
                                  JOIN users u ON lr.doctor_id = u.id WHERE patient_id = ? ORDER BY lr.test_date DESC''',
                               (session['user_id'],)).fetchall()
    appts = conn.execute('''SELECT a.*, u.full_name as doctor_name, s.name as specialization_name
                            FROM appointments a JOIN users u ON a.doctor_id = u.id
                            JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                            WHERE a.patient_id = ? ORDER BY a.appointment_date DESC''',
                         (session['user_id'],)).fetchall()
    conn.close()
    return render_template('health_report.html', records=records, prescriptions=prescs,
                          lab_reports=lab_reports, appointments=appts)

@routes.app.route('/smart_recommend')
@routes.login_required
def smart_recommend():
    if session['role'] != 'patient':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    specializations = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    conn.close()
    return render_template('smart_recommend.html', specializations=specializations)

@routes.app.route('/smart_recommend_results', methods=['POST'])
@routes.login_required
def smart_recommend_results():
    if session['role'] != 'patient':
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))

    specialization = request.form.get('specialization', '')
    conn = routes.get_conn()
    if specialization:
        doctors = conn.execute('''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                                   FROM doctors d JOIN users u ON d.user_id = u.id
                                   JOIN specializations s ON d.specialization_id = s.id
                                   WHERE s.name = ? AND u.availability = 'available'
                                   ORDER BY u.full_name''', (specialization,)).fetchall()
    else:
        doctors = conn.execute('''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                                   FROM doctors d JOIN users u ON d.user_id = u.id
                                   JOIN specializations s ON d.specialization_id = s.id
                                   WHERE u.role = 'doctor' ORDER BY u.full_name''').fetchall()
    specializations = conn.execute('SELECT * FROM specializations ORDER BY name').fetchall()
    conn.close()
    return render_template('smart_recommend.html', doctors=doctors, specialization=specialization,
                          specializations=specializations)

@routes.app.route('/emergency')
def emergency():
    return render_template('emergency.html')

@routes.app.route('/search_doctors')
def search_doctors():
    query = request.args.get('q', '')
    exp_filter = request.args.get('experience', '')
    gender_filter = request.args.get('gender', '')
    fee_range = request.args.get('fee_range', '')
    conn = routes.get_conn()
    if query:
        sql = '''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                    FROM doctors d JOIN users u ON d.user_id = u.id
                    JOIN specializations s ON d.specialization_id = s.id
                    WHERE u.full_name LIKE ? OR s.name LIKE ? OR d.qualification LIKE ?'''
        params = [f'%{query}%', f'%{query}%', f'%{query}%']
        if exp_filter:
            sql += ' AND d.experience >= ?'
            params.append(int(exp_filter))
        if gender_filter:
            sql += ' AND d.gender = ?'
            params.append(gender_filter)
        if fee_range:
            parts = fee_range.split('-')
            if len(parts) == 2:
                sql += ' AND d.consultation_fee >= ? AND d.consultation_fee <= ?'
                params.append(int(parts[0]))
                params.append(int(parts[1]))
        sql += ' ORDER BY u.full_name'
        doctors = conn.execute(sql, params).fetchall()
    else:
        sql = '''SELECT d.*, u.full_name, u.email, u.mobile, s.name as specialization_name
                    FROM doctors d JOIN users u ON d.user_id = u.id
                    JOIN specializations s ON d.specialization_id = s.id'''
        params = []
        if exp_filter:
            sql += ' WHERE d.experience >= ?'
            params.append(int(exp_filter))
        if gender_filter:
            sql += ' WHERE d.gender = ?'
            params.append(gender_filter)
        elif fee_range:
            parts = fee_range.split('-')
            if len(parts) == 2:
                sql += ' WHERE d.consultation_fee >= ? AND d.consultation_fee <= ?'
                params.append(int(parts[0]))
                params.append(int(parts[1]))
        sql += ' ORDER BY u.full_name'
        doctors = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template('doctors.html', doctors=doctors, specializations=[], query=query, exp_filter=exp_filter, gender_filter=gender_filter, fee_range=fee_range)

@routes.app.route('/services')
def services():
    return render_template('services.html')

@routes.app.route('/about')
def about():
    return render_template('about.html')

@routes.app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()
        if name and email and subject and message:
            flash('Message sent successfully. We will get back to you soon.', 'success')
        else:
            flash('Please fill all fields.', 'error')
        return redirect(url_for('contact'))
    return render_template('contact.html')

@routes.app.route('/appointment_confirmation/<int:appt_id>')
@routes.login_required
def appointment_confirmation(appt_id):
    conn = routes.get_conn()
    if session['role'] == 'patient':
        appt = conn.execute('''SELECT a.*, u.full_name as doctor_name, s.name as specialization_name, a.consultation_mode
                                   FROM appointments a
                                   JOIN users u ON a.doctor_id = u.id
                                   JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                                   WHERE a.id = ? AND a.patient_id = ?''', (appt_id, session['user_id'])).fetchone()
    else:
        appt = conn.execute('''SELECT a.*, u.full_name as patient_name, a.consultation_mode
                                   FROM appointments a JOIN users u ON a.patient_id = u.id
                                   WHERE a.id = ?''', (appt_id,)).fetchone()
    conn.close()
    if not appt:
        flash('Appointment not found.', 'error')
        return redirect(url_for('appointments'))
    return render_template('appointment_confirmation.html', appointment=appt)

@routes.app.route('/mark_all_read')
@routes.login_required
def mark_all_read():
    conn = routes.get_conn()
    conn.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (session['user_id'],))
    conn.commit()
    conn.close()
    flash('All notifications marked as read.', 'success')
    return redirect(url_for('notifications_page'))

@routes.app.route('/analytics')
@routes.login_required
@routes.role_required('admin')
def analytics():
    conn = routes.get_conn()
    total_patients = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="patient"').fetchone()
    total_doctors = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="doctor"').fetchone()
    total_appointments = conn.execute('SELECT COUNT(*) as cnt FROM appointments').fetchone()
    pending_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="pending"').fetchone()
    confirmed_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="confirmed"').fetchone()
    completed_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="completed"').fetchone()
    cancelled_appts = conn.execute('SELECT COUNT(*) as cnt FROM appointments WHERE status="cancelled"').fetchone()
    total_records = conn.execute('SELECT COUNT(*) as cnt FROM medical_records').fetchone()
    total_prescriptions = conn.execute('SELECT COUNT(*) as cnt FROM prescriptions').fetchone()
    total_lab_reports = conn.execute('SELECT COUNT(*) as cnt FROM lab_reports').fetchone()

    total_completed = completed_appts['cnt'] if completed_appts else 0
    total_non_cancelled = (pending_appts['cnt'] if pending_appts else 0) + (confirmed_appts['cnt'] if confirmed_appts else 0) + total_completed + (cancelled_appts['cnt'] if cancelled_appts else 0)
    completion_rate = round((total_completed / total_non_cancelled * 100), 1) if total_non_cancelled > 0 else 0

    patient_growth = conn.execute('SELECT COUNT(*) as cnt FROM users WHERE role="patient" AND created_at >= date("now", "-30 days")').fetchone()

    doctor_dist = conn.execute('''SELECT s.name as specialization_name, COUNT(d.id) as doc_count
                                   FROM doctors d JOIN specializations s ON d.specialization_id = s.id
                                   GROUP BY s.name ORDER BY doc_count DESC''').fetchall()

    recent_activity = conn.execute('''SELECT a.id, u.full_name as patient_name, d_u.full_name as doctor_name, a.status, a.appointment_date, a.created_at
                                        FROM appointments a JOIN users u ON a.patient_id = u.id
                                        JOIN users d_u ON a.doctor_id = d_u.id
                                        ORDER BY a.created_at DESC LIMIT 10''').fetchall()
    conn.close()
    return render_template('analytics.html', total_patients=total_patients, total_doctors=total_doctors,
                          total_appointments=total_appointments, pending_appts=pending_appts,
                          confirmed_appts=confirmed_appts, completed_appts=completed_appts,
                          cancelled_appts=cancelled_appts, total_records=total_records,
                          total_prescriptions=total_prescriptions, total_lab_reports=total_lab_reports,
                          completion_rate=completion_rate, patient_growth=patient_growth,
                          doctor_dist=doctor_dist, recent_activity=recent_activity)

@routes.app.route('/billing')
@routes.login_required
@routes.role_required('admin')
def billing():
    conn = routes.get_conn()
    status_filter = request.args.get('status', '')
    sql = '''SELECT a.id as appt_id, a.appointment_date, a.appointment_time, a.status,
                    u.full_name as patient_name, d_u.full_name as doctor_name, d.consultation_fee
             FROM appointments a
             JOIN users u ON a.patient_id = u.id
             JOIN users d_u ON a.doctor_id = d_u.id
             JOIN doctors d ON d.user_id = d_u.id'''
    params = []
    if status_filter:
        sql += ' WHERE a.status = ?'
        params.append(status_filter)
    sql += ' ORDER BY a.created_at DESC'
    invoices = conn.execute(sql, params).fetchall()
    total_revenue = conn.execute('''SELECT COALESCE(SUM(d.consultation_fee), 0) as total
                                   FROM appointments a JOIN users d_u ON a.doctor_id = d_u.id
                                   JOIN doctors d ON d.user_id = d_u.id WHERE a.status = "completed"''').fetchone()
    conn.close()
    return render_template('billing.html', invoices=invoices, total_revenue=total_revenue, status_filter=status_filter)

@routes.app.route('/telehealth')
@routes.login_required
def telehealth():
    conn = routes.get_conn()
    if session['role'] == 'patient':
        teleconsultations = conn.execute('''SELECT t.*, a.appointment_date, a.appointment_time, u.full_name as doctor_name, s.name as specialization_name
                                              FROM telehealth t
                                              JOIN appointments a ON t.appointment_id = a.id
                                              JOIN users u ON a.doctor_id = u.id
                                              LEFT JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                                              WHERE t.patient_id = ? ORDER BY t.consultation_date DESC''',
                                           (session['user_id'],)).fetchall()
    elif session['role'] == 'doctor':
        teleconsultations = conn.execute('''SELECT t.*, a.appointment_date, a.appointment_time, u.full_name as patient_name
                                              FROM telehealth t
                                              JOIN appointments a ON t.appointment_id = a.id
                                              JOIN users u ON a.patient_id = u.id
                                              WHERE t.doctor_id = ? ORDER BY t.consultation_date DESC''',
                                           (session['user_id'],)).fetchall()
    else:
        teleconsultations = []
    conn.close()
    return render_template('telehealth.html', teleconsultations=teleconsultations, role=session.get('role'))

@routes.app.route('/start_consultation/<int:appt_id>')
@routes.login_required
def start_consultation(appt_id):
    if session['role'] not in ['patient', 'doctor']:
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    conn = routes.get_conn()
    appt = conn.execute('SELECT * FROM appointments WHERE id = ?', (appt_id,)).fetchone()
    if not appt:
        flash('Appointment not found.', 'error')
        conn.close()
        return redirect(url_for('appointments'))
    if session['role'] == 'patient' and appt['patient_id'] != session['user_id']:
        flash('Unauthorized.', 'error')
        conn.close()
        return redirect(url_for('appointments'))
    if session['role'] == 'doctor' and appt['doctor_id'] != session['user_id']:
        flash('Unauthorized.', 'error')
        conn.close()
        return redirect(url_for('appointments'))
    existing = conn.execute('SELECT id FROM telehealth WHERE appointment_id = ?', (appt_id,)).fetchone()
    if existing:
        flash('Consultation already started.', 'warning')
        conn.close()
        return redirect(url_for('telehealth'))
    conn.execute('''INSERT INTO telehealth (appointment_id, doctor_id, patient_id, consultation_date, consultation_time, status)
                    VALUES (?, ?, ?, ?, ?, 'active')''',
                 (appt_id, appt['doctor_id'], appt['patient_id'], appt['appointment_date'], appt['appointment_time']))
    conn.commit()
    flash('Consultation started successfully!', 'success')
    conn.close()
    return redirect(url_for('telehealth'))

@routes.app.route('/add_session_notes/<int:tele_id>', methods=['POST'])
@routes.login_required
def add_session_notes(tele_id):
    if session['role'] not in ['patient', 'doctor']:
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    session_notes = request.form.get('session_notes', '').strip()
    if not session_notes:
        flash('Session notes cannot be empty.', 'error')
        return redirect(url_for('telehealth'))
    conn = routes.get_conn()
    tele = conn.execute('SELECT * FROM telehealth WHERE id = ?', (tele_id,)).fetchone()
    if not tele:
        flash('Telehealth consultation not found.', 'error')
        conn.close()
        return redirect(url_for('telehealth'))
    conn.execute('UPDATE telehealth SET session_notes = ?, status = ? WHERE id = ?',
                 (session_notes, 'completed', tele_id))
    conn.commit()
    flash('Session notes added successfully!', 'success')
    conn.close()
    return redirect(url_for('telehealth'))

@routes.app.route('/appointment/<int:appt_id>/telehealth')
@routes.login_required
def appointment_telehealth(appt_id):
    conn = routes.get_conn()
    appt = conn.execute('''SELECT a.*, u.full_name as doctor_name, s.name as specialization_name
                              FROM appointments a
                              JOIN users u ON a.doctor_id = u.id
                              LEFT JOIN specializations s ON (SELECT d.specialization_id FROM doctors d WHERE d.user_id = u.id) = s.id
                              WHERE a.id = ?''', (appt_id,)).fetchone()
    if not appt:
        flash('Appointment not found.', 'error')
        conn.close()
        return redirect(url_for('appointments'))
    tele = conn.execute('SELECT * FROM telehealth WHERE appointment_id = ?', (appt_id,)).fetchone()
    conn.close()
    return render_template('telehealth.html', appointment=appt, telehealth=tele, role=session.get('role'))

@routes.app.route('/audit_log')
@routes.login_required
@routes.role_required('admin')
def audit_log():
    conn = routes.get_conn()
    total_actions = conn.execute('SELECT COUNT(*) as actions FROM audit_logs').fetchone()
    total_logins = conn.execute('SELECT COUNT(*) as logins FROM audit_logs WHERE action = "login"').fetchone()
    total_appts_bookings = conn.execute('SELECT COUNT(*) as bookings FROM audit_logs WHERE action = "appointment_booked"').fetchone()
    total_records = conn.execute('SELECT COUNT(*) as records FROM audit_logs WHERE action IN ("medical_record_added", "prescription_added", "lab_report_added")').fetchone()
    audit_logs = conn.execute('''SELECT al.*, u.full_name as user_full_name FROM audit_logs al JOIN users u ON al.user_id = u.id ORDER BY al.id DESC LIMIT 100''').fetchall()
    conn.close()
    return render_template('audit_log.html', audit_logs=audit_logs, total_actions=total_actions, total_logins=total_logins, total_appts_bookings=total_appts_bookings, total_records=total_records)

@routes.app.errorhandler(404)
def page_not_found(e):
    from flask import render_template
    return render_template('error.html', error_code=404, message='Page not found'), 404

@routes.app.errorhandler(500)
def internal_error(e):
    from flask import render_template
    return render_template('error.html', error_code=500, message='Internal server error'), 500
