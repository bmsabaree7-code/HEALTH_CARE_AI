import sqlite3
import os
import hashlib
from functools import wraps
from flask import session, flash, redirect, url_for, render_template, request
from routes import app, DB_PATH, get_conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            if session.get('role') != role and session.get('role') != 'admin':
                flash('Unauthorized access.', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_current_user():
    if 'user_id' not in session:
        return None
    conn = get_conn()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    return user

@app.context_processor
def inject_user():
    user = None
    if 'user_id' in session:
        user = get_current_user()
    conn = get_conn()
    patients_list = conn.execute('SELECT id, full_name FROM users WHERE role="patient" ORDER BY full_name').fetchall()
    conn.close()
    return dict(current_user=user, patients_list=patients_list)
