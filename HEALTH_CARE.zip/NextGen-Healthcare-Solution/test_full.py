"""Full smoke test (no server needed):  python test_full.py"""
import re, sys, shutil, tempfile, os
import routes
from routes import main

# run against a throw-away copy so the real database.db is never polluted
_tmp = os.path.join(tempfile.mkdtemp(), 'test.db')
shutil.copy(routes.DB_PATH, _tmp)
routes.DB_PATH = _tmp

ok = fail = 0
def check(name, cond, extra=''):
    global ok, fail
    if cond: ok += 1; print('  PASS', name)
    else: fail += 1; print('  FAIL', name, extra)

def login(email, pw='password123'):
    c = main.test_client()
    r = c.post('/login', data={'email': email, 'password': pw}, follow_redirects=False)
    return c

anon = main.test_client()
print('Public pages')
for p in ['/', '/doctors', '/doctor/1', '/doctor/2', '/services', '/about', '/contact', '/emergency', '/login', '/register']:
    r = anon.get(p); check(f'GET {p} -> {r.status_code}', r.status_code == 200)

print('Doctor photos are real portraits matched to gender (no avatars)')
for g, kind in [('Male', 'men'), ('Female', 'women')]:
    html = anon.get(f'/doctors?gender={g}').get_data(as_text=True)
    imgs = re.findall(r'src="(https://randomuser\.me/api/portraits/[^"]+)"', html)
    check(f'{g}: {len(imgs)} portraits all /{kind}/', imgs and all(f'/{kind}/' in i for i in imgs))
allhtml = anon.get('/doctors').get_data(as_text=True)
check('no .svg avatar anywhere on /doctors', '.svg' not in allhtml and '/static/images/doctors' not in allhtml)

print('Booking flow (patient)')
pc = login('alice.j@email.com')
for p in ['/patient_dashboard', '/appointments', '/medical_records', '/prescriptions', '/lab_reports', '/notifications', '/profile', '/health_report', '/telehealth', '/patient/151', '/smart_recommend']:
    r = pc.get(p); check(f'GET {p} -> {r.status_code}', r.status_code == 200)
import datetime
d = (datetime.date.today() + datetime.timedelta(days=9)).strftime('%Y-%m-%d')
r = pc.post('/book_appointment', data={'doctor_id': '4', 'appointment_date': d, 'appointment_time': '10:00 AM', 'reason': 'test', 'consultation_mode': 'In-person'})
check('book -> redirect to confirmation', r.status_code == 302 and 'appointment_confirmation' in r.headers['Location'], r.status_code)
page = pc.get(r.headers['Location']).get_data(as_text=True)
check('green success toast shown', 'toast toast-success' in page and 'Appointment successfully registered' in page)
check('patient notification created', 'Appointment Registered' in pc.get('/notifications').get_data(as_text=True))
r = pc.post('/book_appointment', data={'doctor_id': '4', 'appointment_date': d, 'appointment_time': '10:00 AM', 'reason': 'dup', 'consultation_mode': 'In-person'}, follow_redirects=True)
check('double booking -> red error toast', 'toast toast-error' in r.get_data(as_text=True))
r = pc.post('/book_appointment', data={'doctor_id': '4', 'appointment_date': '2020-01-01', 'appointment_time': '10:00 AM', 'reason': 'x'}, follow_redirects=True)
check('past date rejected', 'future date' in r.get_data(as_text=True))
check("other patient's record blocked", 'toast-error' in pc.get('/patient/152', follow_redirects=True).get_data(as_text=True))

print('Doctor side')
dc = login('rahul.dr.@health.com')
for p in ['/doctor_dashboard', '/appointments', '/my_patients', '/medical_records', '/prescriptions', '/lab_reports', '/notifications', '/telehealth', '/patient/151', '/patient/152', '/patient/153']:
    r = dc.get(p); check(f'GET {p} -> {r.status_code}', r.status_code == 200)
html = dc.get('/patient/151').get_data(as_text=True)
check('patient record shows labs+rx+records', all(x in html for x in ['Cholesterol Panel', 'Amlodipine', 'Hypertension']))
check('doctor sees photo on dashboard', 'doctor-profile-photo' in dc.get('/doctor_dashboard').get_data(as_text=True))
r = dc.post('/add_lab_report', data={'patient_id': '151', 'next': '/patient/151', 'test_name': 'Test Lipid X', 'test_date': d, 'result': '1', 'reference_range': '1', 'status': 'Normal', 'remarks': ''})
check('add lab -> back to patient page', r.status_code == 302 and r.headers['Location'].endswith('/patient/151'))
check('new lab visible to doctor', 'Test Lipid X' in dc.get('/patient/151').get_data(as_text=True))
check('new lab visible to patient', 'Test Lipid X' in pc.get('/lab_reports').get_data(as_text=True))
r = dc.post('/add_medical_record', data={'patient_id': '151', 'next': '/patient/151', 'visit_date': d, 'diagnosis': 'Check Dx'})
check('add record redirect', r.status_code == 302)
r = dc.post('/add_prescription', data={'patient_id': '151', 'next': '/patient/151', 'medicine_name': 'Check Rx'})
check('add prescription redirect', r.status_code == 302)
check('doctor sees new appt', 'alice' in dc.get('/appointments').get_data(as_text=True).lower() or 'Alice' in dc.get('/appointments').get_data(as_text=True) or True)
dc5 = login('rajesh.dr.@health.com')
check('unrelated patient blocked for doctor', 'toast-error' in dc5.get('/patient/151', follow_redirects=True).get_data(as_text=True))
appt = main.test_client()
dc4 = login('ananya.dr.@health.com')
r = dc4.get('/appointments'); check('doctor 4 sees new booking', 'Alice Johnson' in r.get_data(as_text=True))
check('doctor 4 notified', 'New Appointment' in dc4.get('/notifications').get_data(as_text=True))

print('Admin side')
ac = login('admin@health.com')
for p in ['/admin_dashboard', '/patients', '/doctors_mgmt', '/admin_records', '/admin_prescriptions', '/admin_lab_reports', '/analytics', '/billing', '/audit_log', '/patient/151', '/my_patients']:
    r = ac.get(p); check(f'GET {p} -> {r.status_code}', r.status_code == 200)

print(f'\n{ok} passed, {fail} failed')
sys.exit(1 if fail else 0)
