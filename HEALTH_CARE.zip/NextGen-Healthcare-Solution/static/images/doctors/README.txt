DOCTOR PHOTOS  (white coat + stethoscope, real people, all countries)
=====================================================================
Put the photos here:

  men/     ->  male doctor photos      (.jpg .jpeg .png .webp)
  women/   ->  female doctor photos

How many?
  * 75 in men/ + 75 in women/  = every one of the 150 doctors gets a different photo (best).
  * minimum 35 + 35 = 70       = the first 70 doctors never repeat; photos only repeat after that.

Tips
  * Square-ish crop, face + white coat + stethoscope visible, 400x400 px or more is enough.
  * Mix countries/ethnicities - photos are shuffled with a fixed seed, so neighbours look different.
  * File names do not matter (india_01.jpg, nigeria_02.jpg ... is fine).

After adding photos just restart the app (python app.py). Old randomuser.me / unsplash
photos are replaced automatically; photos uploaded by doctors themselves are never changed.
Until photos are added, doctors show the grey placeholder (placeholder.svg).
