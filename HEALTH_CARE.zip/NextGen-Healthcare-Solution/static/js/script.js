function toggleNav() {
    var navLinks = document.querySelector('.nav-links');
    if (navLinks.style.display === 'flex') {
        navLinks.style.display = 'none';
    } else {
        navLinks.style.display = 'flex';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            alert.style.opacity = '1';
        });
    }, 100);
});

function confirmAction(msg) {
    return confirm(msg);
}

function toggleNotification(id) {
    fetch('/mark_notification_read/' + id)
        .then(function() {
            window.location.reload();
        });
}

function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    var d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function showToast(message, type) {
    var cat = (type === 'success' || type === 'error') ? type : 'info';
    var titles = { success: 'Success', error: 'Error', info: 'Info' };
    var icons = { success: 'check-circle', error: 'exclamation-circle', info: 'info-circle' };
    var box = document.getElementById('toastContainer');
    if (!box) return;
    var t = document.createElement('div');
    t.className = 'toast toast-' + cat;
    t.setAttribute('role', 'alert');
    t.innerHTML = '<div class="toast-icon"><i class="fas fa-' + icons[cat] + '"></i></div>' +
        '<div class="toast-text"><strong>' + titles[cat] + '</strong><span></span></div>' +
        '<button class="toast-close" aria-label="Close">&times;</button><div class="toast-progress"></div>';
    t.querySelector('span').textContent = message;
    t.querySelector('.toast-close').onclick = function () { t.remove(); };
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, 6400);
}

// remove server-rendered toasts after their CSS animation ends
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.toast').forEach(function (t) {
        setTimeout(function () { t.remove(); }, 6500);
    });
    // booking form: block past dates + show "booking..." state
    var d = document.querySelector('.booking-form input[type="date"]');
    if (d) { d.min = new Date().toISOString().split('T')[0]; }
    var f = document.querySelector('.booking-form');
    if (f) {
        f.addEventListener('submit', function () {
            var b = f.querySelector('button[type="submit"]');
            if (b) { b.disabled = true; b.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Booking...'; }
        });
    }
    // patient record tabs
    document.querySelectorAll('.pr-tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.pr-tab').forEach(function (x) { x.classList.remove('active'); });
            document.querySelectorAll('.pr-pane').forEach(function (x) { x.classList.remove('active'); });
            tab.classList.add('active');
            document.getElementById(tab.dataset.pane).classList.add('active');
        });
    });
});
