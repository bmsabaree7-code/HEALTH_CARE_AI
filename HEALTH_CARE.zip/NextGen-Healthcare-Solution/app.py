from routes import main

if __name__ == '__main__':
    main.run(debug=True, port=5000)
